CREATE TABLE public.saved_properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 200),
  snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_properties TO authenticated;
GRANT ALL ON public.saved_properties TO service_role;
ALTER TABLE public.saved_properties ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own properties select" ON public.saved_properties FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Own properties insert" ON public.saved_properties FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Own properties update" ON public.saved_properties FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Own properties delete" ON public.saved_properties FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX saved_properties_user_idx ON public.saved_properties(user_id, updated_at DESC);

-- Shared read-only reports: no direct table access; only via functions below.
CREATE TABLE public.shared_reports (
  slug text PRIMARY KEY,
  snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.shared_reports TO service_role;
ALTER TABLE public.shared_reports ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.create_shared_report(_snapshot jsonb)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _slug text;
BEGIN
  IF pg_column_size(_snapshot) > 200000 THEN RAISE EXCEPTION 'Report too large'; END IF;
  _slug := translate(encode(extensions.gen_random_bytes(9), 'base64'), '+/=', '-_');
  INSERT INTO public.shared_reports(slug, snapshot) VALUES (_slug, _snapshot);
  RETURN _slug;
END $$;

CREATE OR REPLACE FUNCTION public.get_shared_report(_slug text)
RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT snapshot FROM public.shared_reports WHERE slug = _slug
$$;

REVOKE ALL ON FUNCTION public.create_shared_report(jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_shared_report(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_shared_report(jsonb) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_shared_report(text) TO anon, authenticated;