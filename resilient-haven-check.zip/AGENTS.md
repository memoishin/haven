<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- Data providers live in `src/lib/haven/providers.functions.ts` as server functions; each provider has its own timeout/cache and returns an `Evidence` record with status, so one failure never breaks the app.
- All scoring formulas live in `src/lib/haven/model.ts` (pure, tested); UI components never compute hazard results themselves.
- User site overrides are stored separately from fetched evidence and merged via `effectiveSite`, so source evidence is never overwritten.
- App state lives in one React context (`src/lib/haven/state.tsx`); changing location clears evidence/photo/site overrides but keeps house and upgrades.
- The user journey has four stages: Address, Profile, Upgrades, and Compare; Profile composes site, house, and current-house scenario views so those inputs stay together.
- Visual styling uses the Ocean & Citrus semantic palette with Outfit headings and Figtree body text for an energetic, trustworthy feel.
- Saved places live in `saved_properties` (owner RLS, browser client); shared reports live in `shared_reports`, reachable only via security-definer RPCs `create_shared_report` / `get_shared_report` so slugs cannot be enumerated.
- Snapshots (`toSnapshot`/`load` in state.tsx) are the single format for saving, sharing and PDF; `report.ts` builds report text from a snapshot only.
- Auto-filled values (`autoSite`, `autoHouse`, `presetsFor` in model.ts) never overwrite user edits; sparse mapping leaves values unknown rather than guessing.
