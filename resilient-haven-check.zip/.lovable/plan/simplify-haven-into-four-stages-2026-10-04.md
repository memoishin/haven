# Simplify Haven into four stages

## What will change
- Replace the five-step journey with: **Address → Profile → Upgrades → Compare**.
- Combine site details, current house profile, and a simple current-house scenario into **Profile**.
- Reduce visible explanations; keep source details, assumptions, and advanced settings inside expandable panels.
- Add recognizable icons to stage navigation, hazard choices, profile summaries, and upgrade groups.
- Make upgrades easier to choose with hazard filters, a one-click suggested set, clear selected counts, and short plain-language cards.
- Keep the final comparison focused on the same event before and after upgrades, with a clear way back to edit upgrades and simulate again.

## Interaction details
- Preserve worldwide address search, evidence labels, source transparency, model formulas, and all 20 upgrade controls.
- Keep free navigation after an address is selected, plus persistent Back/Continue actions.
- Keep full simulation controls available, but move secondary settings behind compact sections.
- Ensure mobile controls remain large, keyboard accessible, and reduced-motion friendly.

## Technical details
- Keep provider, evidence, modelling, and state architecture unchanged.
- Recompose the existing site, house, upgrade, and simulation views into the four-stage flow.
- Update step state bounds and navigation labels without changing hazard calculations.
- Verify the main journey on desktop and mobile, then check tests and preview diagnostics.
