# Make Haven a usable tool

The goal: fewer questions, more data filled in for you, real hazard numbers, costs, saved reports.

## 1. Fill details in automatically (fewer options)
- Fill house and site details from public data wherever possible: building type and levels from OpenStreetMap building tags, surroundings from land use, hard-surface share from mapped land cover, wind exposure from slope and elevation.
- Each auto-filled value shows a small "Auto" badge. One tap lets you change it.
- Hide "Edit details" by default. Ask only what data can't answer: floor height and renting vs owning.
- Mild/Strong/Extreme presets come from real local data where it exists (see 2), not fixed numbers.

## 2. Real hazard data (public, free, worldwide)
- Flood: river discharge history and forecast (Open-Meteo / GloFAS). Show the largest flow on record and the current outlook.
- Heat: hottest days in recent decades and future projections (Open-Meteo historical + CMIP6 climate). The "Extreme" preset uses the local 30-year maximum.
- Wind and cyclone: strongest gusts on record (ERA5 reanalysis). Presets come from local maximums.
- Fire: recent mapped fires nearby (NASA FIRMS; this needs a free key, which I'll ask you for) plus local fire-weather days.
- Every number keeps its source, date and limits. If data is missing, it says "Data unavailable". Nothing is invented.

## 3. Cost estimates
- Each upgrade shows a low–high cost range from public guidance, scaled by house size and adjusted by country price level (World Bank price data).
- Labelled "Rough estimate — get local quotes". The Compare screen shows a total for the upgrades you picked.

## 4. Save and share (sign-in optional)
- Optional sign-in with email or Google. The app still works without an account.
- Signed-in users can save properties and come back to them later.
- Share link: a read-only report page anyone can open.
- Download a PDF report with location, evidence, house, chosen upgrades, before/after results and costs.

## 5. Reliability
- Faster loading: data sources load in parallel and results stream in as they arrive.
- Cache results in Cloud so places people revisit load instantly.
- Automatic retry for slow sources, plus a clear "Retry" button for each missing item.
- Fix soil data often coming back empty (fallback query plus a wider search).

## Technical details
- Enable Lovable Cloud: `properties`, `reports` (public share via slug, owner RLS), `evidence_cache` tables; Google + email auth.
- New providers in `providers.functions.ts`: floodHistory, climateExtremes, gustHistory, firms, landCover, buildingTags, priceLevel, each with its own timeout and cache and returning `Evidence`.
- `model.ts`: `autoSite()` derivation and `costRange()`, both pure and tested; presets derived from evidence and falling back to the current defaults.
- PDF made in the browser with jsPDF. Share page at a public route `/r/$slug` with its own head metadata.
- Delivered in stages: auto-fill and real data first, then costs, then accounts/save/share/PDF.
