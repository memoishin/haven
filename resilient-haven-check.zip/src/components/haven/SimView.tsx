import { useRef } from "react";
import type { Calibration, FloodKind, Hazard, Photo } from "@/lib/haven/types";
import { Particles } from "./Particles";
import { cn } from "@/lib/utils";
import { Pill } from "./ui";

export interface SimViewProps {
  photo: Photo | null;
  calib: Calibration;
  hazard: Hazard;
  floodKind: FloodKind;
  /** current event intensity (depth m, exposure, °C, km/h) */
  current: number;
  /** 0..1 normalised current severity for visual layers */
  level: number;
  stress: number;
  floorM: number;
  addedM: number;
  badge: string;
  showCalib?: boolean;
  onDragDepth?: (m: number) => void;
}

export function SimView({ photo, calib, hazard, floodKind, current, level, stress, floorM, addedM, badge, showCalib, onDragDepth }: SimViewProps) {
  const box = useRef<HTMLDivElement>(null);
  const k = (calib.groundPct - calib.eavesPct) / Math.max(0.5, calib.groundToEavesM); // % of height per metre
  const yAt = (m: number) => calib.groundPct - m * k;
  const waterTop = yAt(current);
  const s = stress / 10;

  const dragTo = (clientY: number) => {
    if (!box.current || !onDragDepth) return;
    const r = box.current.getBoundingClientRect();
    const pct = ((clientY - r.top) / r.height) * 100;
    onDragDepth(Math.max(0, Math.min(3, (calib.groundPct - pct) / k)));
  };

  return (
    <div
      ref={box}
      className={cn("relative aspect-[4/3] w-full overflow-hidden rounded-xl border bg-muted select-none", onDragDepth && hazard === "flood" && "cursor-ns-resize touch-none")}
      onPointerDown={(e) => {
        if (!onDragDepth || hazard !== "flood") return;
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        dragTo(e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.buttons && onDragDepth && hazard === "flood") dragTo(e.clientY);
      }}
    >
      {photo ? (
        <img src={photo.url} alt={photo.kind === "example" ? "Example house photograph (not this address)" : `Photo: ${photo.title}`} className="absolute inset-0 h-full w-full object-cover" draggable={false} />
      ) : (
        <div className="absolute inset-0 grid place-items-center text-sm text-muted-foreground">Loading photo…</div>
      )}

      {hazard === "heat" && photo && (
        <>
          <img src={photo.url} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover animate-heat blur-[0.6px]" style={{ opacity: 0.5 * level }} draggable={false} />
          <div className="absolute inset-0 heat-veil mix-blend-multiply" style={{ opacity: 0.55 * level }} />
          <div className="absolute rounded-full heat-veil animate-glint" style={{ left: "25%", width: "50%", top: `${calib.eavesPct - 5}%`, height: `${calib.groundPct - calib.eavesPct}%`, opacity: s }} aria-hidden />
        </>
      )}

      {hazard === "fire" && (
        <>
          <div className="absolute inset-0 smoke-veil" style={{ opacity: 0.75 * level }} />
          <Particles mode="embers" intensity={level} />
          {[20, 50, 78].map((x) => (
            <span key={x} aria-hidden className="absolute size-5 -translate-x-1/2 rounded-full border-2 border-ember animate-pulse-ring" style={{ left: `${x}%`, top: `${calib.eavesPct}%`, opacity: s * level }} />
          ))}
        </>
      )}

      {(hazard === "wind" || hazard === "cyclone") && (
        <>
          <div className="absolute inset-0 wind-veil" style={{ opacity: level }} />
          <Particles mode="wind" intensity={level} />
          <Particles mode="rain" intensity={level * 0.6} />
          {[30, 70].map((x) => (
            <span key={x} aria-hidden className="absolute size-5 -translate-x-1/2 rounded-full border-2 border-wind animate-pulse-ring" style={{ left: `${x}%`, top: `${calib.eavesPct - 6}%`, opacity: s * level }} />
          ))}
        </>
      )}

      {hazard === "flood" && (
        <>
          {floodKind !== "coastal" && <Particles mode="rain" intensity={Math.min(1, 0.3 + level)} />}
          {floodKind === "coastal" && <Particles mode="wind" intensity={level * 0.5} />}
          {current > 0.01 && (
            <div className="absolute inset-x-0 bottom-0 water-body transition-[top] duration-150" style={{ top: `${waterTop}%` }}>
              <svg className={cn("absolute -top-3 left-0 h-4 w-[200%]", floodKind === "coastal" ? "animate-wave-fast h-6 -top-5" : "animate-wave")} viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden>
                <path d="M0 10 Q25 0 50 10 T100 10 T150 10 T200 10 T250 10 T300 10 T350 10 T400 10 V20 H0Z" className="fill-water" />
              </svg>
              <div className="absolute inset-x-0 top-1 h-6 bg-gradient-to-b from-wind/40 to-transparent animate-glint" />
            </div>
          )}
          <Guide y={yAt(floorM)} label={`Floor ${floorM.toFixed(2)} m`} />
          {addedM > 0 && <Guide y={yAt(floorM + addedM)} label={`Raised floor ${(floorM + addedM).toFixed(2)} m`} strong />}
        </>
      )}

      {showCalib && (
        <>
          <Guide y={calib.groundPct} label="Ground line" calib />
          <Guide y={calib.eavesPct} label={`Eaves line (${calib.groundToEavesM} m)`} calib />
        </>
      )}

      <div className="absolute left-2 top-2 flex flex-wrap gap-1">
        <Pill tone="primary">{badge}</Pill>
        {photo?.kind === "example" && <Pill tone="caution">Example house — not this address</Pill>}
        {photo?.kind === "nearby" && <Pill tone="caution">{photo.confirmedByUser ? "Nearby photo — you confirmed" : "Nearby photo — unconfirmed"}</Pill>}
      </div>
      <div className="absolute bottom-2 right-2">
        <Pill>Illustrative scenario</Pill>
      </div>
    </div>
  );
}

function Guide({ y, label, strong, calib }: { y: number; label: string; strong?: boolean; calib?: boolean }) {
  return (
    <div className="pointer-events-none absolute inset-x-0" style={{ top: `${y}%` }} aria-hidden>
      <div className={cn("border-t-2 border-dashed", calib ? "border-caution" : strong ? "border-primary-foreground" : "border-card/80")} />
      <span className={cn("absolute left-2 -translate-y-full rounded px-1.5 py-0.5 text-[10px] font-semibold", calib ? "bg-caution text-caution-foreground" : "bg-foreground/70 text-primary-foreground")}>{label}</span>
    </div>
  );
}
