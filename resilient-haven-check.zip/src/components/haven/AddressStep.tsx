import { lazy, Suspense, useState } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, MapPin, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { geocode, reverseGeocode } from "@/lib/haven/providers.functions";
import { useHaven } from "@/lib/haven/state";
import type { Place } from "@/lib/haven/types";
import { Expand, Pill } from "./ui";
import { PRECISION_LABEL } from "./LocationBar";

const MapPicker = lazy(() => import("./MapPicker"));

/** Demo points: coordinates only. All evidence is fetched live from public sources. */
const DEMOS: { name: string; setting: string; lat: number; lon: number; country: string }[] = [
  { name: "Rocklea, Brisbane", setting: "River floodplain suburb", lat: -27.5446, lon: 153.0005, country: "Australia" },
  { name: "Paradise, California", setting: "Forested ridge town", lat: 39.7596, lon: -121.6219, country: "United States" },
  { name: "Rotterdam", setting: "Low-lying delta city", lat: 51.9225, lon: 4.4792, country: "Netherlands" },
  { name: "Suva", setting: "Tropical coastal capital", lat: -18.1416, lon: 178.4419, country: "Fiji" },
  { name: "Marsabit", setting: "Rural, sparse mapping", lat: 2.3284, lon: 37.9899, country: "Kenya" },
  { name: "Seville", setting: "Hot inland city", lat: 37.3891, lon: -5.9845, country: "Spain" },
];

export function AddressStep() {
  const { s, selectPlace } = useHaven();
  const search = useServerFn(geocode);
  const reverse = useServerFn(reverseGeocode);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<Place[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [lat, setLat] = useState("");
  const [lon, setLon] = useState("");
  const [pin, setPin] = useState<[number, number] | null>(s.place ? [s.place.lat, s.place.lon] : null);

  const run = async (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim().length < 2) return;
    setBusy(true); setErr(null);
    try {
      const r = await search({ data: { q } });
      setResults(r.results);
      setErr(r.error ?? (r.results.length ? null : "No matches. Try a town name, a map point or coordinates."));
    } catch {
      setErr("Search failed. Try a map point or coordinates.");
    } finally { setBusy(false); }
  };

  const pickPoint = async (la: number, lo: number, demo?: boolean, name?: string) => {
    setPin([la, lo]); setBusy(true);
    try {
      const p = await reverse({ data: { lat: la, lon: lo } });
      selectPlace(demo ? { ...p, label: `${name} (demo point)`, demo: true, precision: "locality" } : p);
    } catch {
      selectPlace({ lat: la, lon: lo, label: `${la.toFixed(5)}, ${lo.toFixed(5)}`, precision: "manual", source: "Manually entered" });
    } finally { setBusy(false); }
  };

  const coordErr = (() => {
    if (!lat && !lon) return null;
    const a = Number(lat), b = Number(lon);
    if (!Number.isFinite(a) || a < -90 || a > 90) return "Latitude must be between −90 and 90.";
    if (!Number.isFinite(b) || b < -180 || b > 180) return "Longitude must be between −180 and 180.";
    return null;
  })();

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <div className="space-y-2 pt-4 text-center sm:pt-10">
        <h1 className="font-display text-5xl leading-tight sm:text-6xl">Start with an address.</h1>
        <p className="text-muted-foreground">Check the location, ground and home. Try upgrades.</p>
      </div>

      <form onSubmit={run} className="flex gap-2" role="search">
        <label htmlFor="addr" className="sr-only">Address, town or place</label>
        <input
          id="addr"
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Address, town or place — anywhere"
          className="h-14 min-w-0 flex-1 rounded-2xl border border-input bg-card px-4 text-base shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        />
        <Button type="submit" className="h-14 rounded-2xl px-5" disabled={busy} aria-label="Search">
          {busy ? <Loader2 className="animate-spin" /> : <Search />}
        </Button>
      </form>

      {err && <p className="rounded-lg bg-caution px-3 py-2 text-sm text-caution-foreground" role="status">{err}</p>}

      {results && results.length > 0 && (
        <ul className="divide-y rounded-xl border bg-card" aria-label="Search results">
          {results.map((r, i) => (
            <li key={i}>
              <button onClick={() => selectPlace(r)} className="flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-accent focus-visible:bg-accent focus-visible:outline-none">
                <MapPin className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{r.label.split(",")[0]}</span>
                  <span className="block truncate text-xs text-muted-foreground">{[r.locality, r.region, r.country].filter(Boolean).join(" · ")}</span>
                </span>
                <Pill tone={r.precision === "address" ? "evidence" : "caution"}>{PRECISION_LABEL[r.precision]}</Pill>
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="text-center text-[11px] text-muted-foreground">Search by OpenStreetMap Nominatim · © OpenStreetMap contributors</p>

      <Expand title="No street address? Pick on a map">
        <ClientOnly fallback={<div className="h-72 rounded-xl bg-muted" />}>
          <Suspense fallback={<div className="h-72 rounded-xl bg-muted" />}>
            <MapPicker center={pin ?? [10, 0]} marker={pin} onPick={(a, b) => pickPoint(a, b)} />
          </Suspense>
        </ClientOnly>
        <p className="mt-2 text-xs text-muted-foreground">Clicking sets a manually selected point.</p>
      </Expand>

      <Expand title="Enter coordinates">
        <form className="grid grid-cols-2 gap-2" onSubmit={(e) => { e.preventDefault(); if (!coordErr && lat && lon) pickPoint(Number(lat), Number(lon)); }}>
          <label className="text-sm">Latitude (°)<input inputMode="decimal" value={lat} onChange={(e) => setLat(e.target.value)} placeholder="-18.14" className="mt-1 h-11 w-full rounded-lg border border-input bg-card px-3" /></label>
          <label className="text-sm">Longitude (°)<input inputMode="decimal" value={lon} onChange={(e) => setLon(e.target.value)} placeholder="178.44" className="mt-1 h-11 w-full rounded-lg border border-input bg-card px-3" /></label>
          {coordErr && <p className="col-span-2 text-xs text-destructive">{coordErr}</p>}
          <Button type="submit" variant="outline" className="col-span-2 h-11" disabled={!!coordErr || !lat || !lon}>Use these coordinates</Button>
        </form>
      </Expand>

      <div className="space-y-2">
        <h2 className="text-sm font-medium">Or try a demo point</h2>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {DEMOS.map((d) => (
            <button key={d.name} onClick={() => pickPoint(d.lat, d.lon, true, d.name)} disabled={busy} className="rounded-xl border bg-card p-3 text-left hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50">
              <span className="block text-sm font-medium">{d.name}</span>
              <span className="block text-xs text-muted-foreground">{d.country} · {d.setting}</span>
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">Demo points are locality locations, not specific properties. All data is fetched live.</p>
      </div>
    </div>
  );
}
