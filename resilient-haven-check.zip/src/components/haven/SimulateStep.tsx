import { useEffect, useMemo, useRef, useState } from "react";
import { Flame, Pause, Play, RotateCcw, SkipForward, Repeat, ThermometerSun, Tornado, Waves, Wind } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useHaven } from "@/lib/haven/state";
import { computeResult, effectiveSite, envelope, INTENSITY, intensityAt, presetsFor, stressBand } from "@/lib/haven/model";
import type { Hazard, SiteInputs } from "@/lib/haven/types";
import { COST_SOURCE, costRange, fmtUsd, HAZARD_LABEL, UPGRADES, upgradeGroup } from "@/lib/haven/upgrades";
import { SimView } from "./SimView";
import { ReportActions } from "./ReportActions";
import { HazardUpgrades } from "./UpgradesPanel";
import { PhotoCredit } from "./HouseStep";
import { Pill, RangeField, Segmented, Select } from "./ui";
import { cn } from "@/lib/utils";

const HAZARDS: Hazard[] = ["flood", "fire", "heat", "wind", "cyclone"];
const HAZARD_ICONS = { flood: Waves, fire: Flame, heat: ThermometerSun, wind: Wind, cyclone: Tornado };
const DURATION = 12; // seconds at 1×

export function SimulateStep() {
  const { s, set } = useHaven();
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [loop, setLoop] = useState(false);
  const [view, setView] = useState<"original" | "upgraded" | "side">("side");
  const raf = useRef(0);

  useEffect(() => {
    if (!playing) return;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      setT((prev) => {
        let n = prev + (dt * speed) / DURATION;
        if (n >= 1) {
          if (loop) n = 0;
          else { n = 1; setPlaying(false); }
        }
        return n;
      });
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [playing, speed, loop]);

  const h = s.hazard;
  const peak = s.intensity[h];
  const cfg = INTENSITY[h];
  const site = useMemo(() => effectiveSite(s.site, s.evidence), [s.site, s.evidence]);
  const current = intensityAt(h, peak, t);
  const level = envelope(t) * ((peak - cfg.min) / (cfg.max - cfg.min) * 0.8 + 0.2);
  // Same event (current intensity), same site — only upgrades differ.
  const orig = computeResult(h, current, s.floodKind, s.house, site, s.upgrades, false);
  const upg = computeResult(h, current, s.floodKind, s.house, site, s.upgrades, true);
  const origPeak = computeResult(h, peak, s.floodKind, s.house, site, s.upgrades, false);
  const upgPeak = computeResult(h, peak, s.floodKind, s.house, site, s.upgrades, true);
  const presets = presetsFor(h, s.evidence);
  const pl = s.evidence?.priceLevel?.status === "estimate" ? s.evidence.priceLevel.value ?? null : null;
  const onList = UPGRADES.filter((u) => u.hazard === upgradeGroup(h) && s.upgrades[u.id].on);
  const cost = onList.reduce<[number, number]>((a, u) => { const [l, hi] = costRange(u.id, s.upgrades[u.id].value, pl, s.house.type === "apartment"); return [a[0] + l, a[1] + hi]; }, [0, 0]);
  const hazardUpOn = onList.length > 0;
  const added = s.upgrades.raise_floor.on ? s.upgrades.raise_floor.value : 0;

  // light gamification: explored = reached peak; compared = viewed upgrades with ≥1 on
  useEffect(() => {
    if (t >= 0.5 && !s.explored.includes(h)) set((x) => ({ explored: [...x.explored, h] }));
  }, [t, h, s.explored, set]);
  useEffect(() => {
    if (t >= 0.5 && hazardUpOn && view !== "original" && !s.compared.includes(h)) set((x) => ({ compared: [...x.compared, h] }));
  }, [t, h, hazardUpOn, view, s.compared, set]);

  const setPeak = (v: number) => set((x) => ({ intensity: { ...x.intensity, [h]: Math.min(cfg.max, Math.max(cfg.min, v)) } }));
  const dragDepth = (m: number) => {
    setPeak(Math.round(m / 0.05) * 0.05);
    if (t < 0.5) setT(0.5); // show the peak while dragging
  };
  const upd = (p: Partial<SiteInputs>) => set((x) => ({ site: { ...x.site, ...p } }));

  const viewProps = { photo: s.photo, calib: s.calib, hazard: h, floodKind: s.floodKind, current, level, floorM: s.house.floorHeightM };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="text-xs font-semibold uppercase text-primary">Step 4 · Compare</p>
          <h1 className="font-display text-4xl font-bold">Compare</h1>
          <p className="text-sm text-muted-foreground">Current house and selected upgrades. Same event.</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground" aria-live="polite">
          <span>Explored {s.explored.length}/4</span>
          <span aria-hidden>·</span>
          <span>Compared {s.compared.length}/4</span>
          <span className="flex gap-1" aria-hidden>
            {HAZARDS.map((x) => <span key={x} className={cn("size-2 rounded-full", s.compared.includes(x) ? "bg-primary" : s.explored.includes(x) ? "bg-primary/40" : "bg-border")} />)}
          </span>
        </div>
      </div>

      <div role="tablist" aria-label="Hazard" className="flex gap-1 overflow-x-auto rounded-xl border bg-muted p-1">
        {HAZARDS.map((x) => {
          const Icon = HAZARD_ICONS[x];
          return (
            <Button key={x} type="button" variant={h === x ? "secondary" : "ghost"} role="tab" aria-selected={h === x} onClick={() => set(() => ({ hazard: x }))} className="min-h-10 flex-1 whitespace-nowrap px-2 text-xs sm:text-sm">
              <Icon className="size-4" aria-hidden /><span className="hidden sm:inline">{HAZARD_LABEL[x]}</span><span className="sm:hidden">{x === "fire" ? "Fire" : x[0]?.toUpperCase()}{x.slice(1)}</span>
            </Button>
          );
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="space-y-3">
          <div className={cn("grid gap-2", view === "side" && "sm:grid-cols-2")}>
            {view !== "upgraded" && <SimView {...viewProps} stress={orig.stress} addedM={0} badge="Original" onDragDepth={dragDepth} />}
            {view !== "original" && <SimView {...viewProps} stress={upg.stress} addedM={added} badge="With upgrades" onDragDepth={dragDepth} />}
          </div>
          <PhotoCredit photo={s.photo} />
          {h === "flood" && <p className="text-xs text-muted-foreground">Drag up or down on the photo to set water depth, or use the slider in Event.</p>}

          {/* transport */}
          <div className="space-y-3 rounded-xl border bg-card p-3">
            <div className="flex flex-wrap items-center gap-2">
              <Button size="icon" onClick={() => { if (t >= 1) setT(0); setPlaying((p) => !p); }} aria-label={playing ? "Pause" : "Play"} className="size-11">{playing ? <Pause /> : <Play />}</Button>
              <Button size="icon" variant="outline" onClick={() => { setT(0); setPlaying(true); }} aria-label="Replay" className="size-11"><RotateCcw /></Button>
              <Button variant="outline" className="h-11" onClick={() => { setPlaying(false); setT(0.5); }}><SkipForward /> Peak</Button>
              <Button variant="ghost" className="h-11" onClick={() => { setPlaying(false); setT(0); }}>Reset</Button>
              <label className="ml-auto flex items-center gap-2 text-xs">
                Speed
                <select value={speed} onChange={(e) => setSpeed(Number(e.target.value))} className="h-9 rounded-lg border bg-card px-2">
                  {[0.5, 1, 2, 4].map((v) => <option key={v} value={v}>{v}×</option>)}
                </select>
              </label>
              <label className="flex items-center gap-2 text-xs"><Repeat className="size-4" aria-hidden /> Loop <Switch checked={loop} onCheckedChange={setLoop} aria-label="Loop" /></label>
            </div>
            <div className="flex items-center gap-3">
              <span className="w-12 text-xs tabular-nums text-muted-foreground">{t < 0.5 ? "Build" : t < 0.55 ? "Peak" : "Ease"}</span>
              <Slider aria-label="Timeline" value={[t * 100]} min={0} max={100} step={0.5} onValueChange={(v) => { setPlaying(false); setT((v[0] ?? 0) / 100); }} className="flex-1 py-2" />
            </div>
          </div>

          {/* outcome */}
          <div className="grid gap-2 sm:grid-cols-2">
            {[{ name: "Original", r: orig, p: origPeak }, { name: "With upgrades", r: upg, p: upgPeak }].map(({ name, r, p }) => (
              <div key={name} className="rounded-xl border bg-card p-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold">{name}</h3>
                  <Pill tone={name === "Original" ? "muted" : "evidence"}>Peak index {p.stress.toFixed(1)}/10</Pill>
                </div>
                <dl className="mt-2 space-y-1 text-sm">
                  {r.metrics.map((m) => (
                    <div key={m.label} className="flex justify-between gap-2">
                      <dt className="text-muted-foreground">{m.label}</dt>
                      <dd className={cn("tabular-nums text-right", m.emphasis && "font-semibold")}>{m.value}</dd>
                    </div>
                  ))}
                  <div className="flex justify-between gap-2 border-t pt-1">
                    <dt className="text-muted-foreground">Illustrative stress index (now)</dt>
                    <dd className="font-semibold tabular-nums">{r.stress.toFixed(1)}/10</dd>
                  </div>
                </dl>
              </div>
            ))}
          </div>
          <p className="rounded-xl bg-secondary/60 p-3 text-sm" aria-live="polite">
            {explain(h, origPeak.stress, upgPeak.stress, hazardUpOn, s.house.mode === "rent")} {upg.notes.join(" ")}
          </p>
          {hazardUpOn && (
            <p className="rounded-xl border bg-card p-3 text-sm"><span className="font-semibold">Rough cost of these {onList.length} upgrades: {fmtUsd(cost[0])}–{fmtUsd(cost[1])}</span><br /><span className="text-[11px] text-muted-foreground">{COST_SOURCE}</span></p>
          )}
          <ReportActions />
          <p className="text-[11px] text-muted-foreground">Illustrative stress index: 0 = minimal, 10 = highest stress in this teaching model. Not a probability, damage percentage or safety rating.</p>
        </div>

        {/* controls */}
        <Tabs defaultValue="event" className="w-full">
          <TabsList className="grid h-11 w-full grid-cols-3">
            <TabsTrigger value="event">Event</TabsTrigger>
            <TabsTrigger value="upgrades">Upgrades</TabsTrigger>
            <TabsTrigger value="site">Site</TabsTrigger>
          </TabsList>
          <TabsContent value="event" className="space-y-4 rounded-xl border bg-card p-4">
            <Segmented label="View" value={view} onChange={setView} options={[{ v: "original", l: "Original" }, { v: "upgraded", l: "Upgrades" }, { v: "side", l: "Side by side" }]} />
            {h === "flood" && (
              <Select label="Flood type" value={s.floodKind} onChange={(v) => set(() => ({ floodKind: v }))} options={[{ v: "river", l: "River / catchment" }, { v: "surface", l: "Surface water / heavy rain" }, { v: "coastal", l: "Coastal / storm tide" }]} />
            )}
            <div className="flex gap-2">
              {(["Mild", "Strong", "Extreme"] as const).map((n, i) => (
                <Button key={n} variant={peak === presets.values[i] ? "default" : "outline"} className="h-10 flex-1" onClick={() => { const preset = presets.values[i]; if (preset != null) setPeak(preset); }}>{n}</Button>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground">{presets.local ? presets.basis : "Generic levels — no local record available."}</p>
            <RangeField label={cfg.label} value={peak} min={cfg.min} max={cfg.max} step={cfg.step} unit={cfg.unit} format={(v) => `${h === "flood" ? v.toFixed(2) : v} ${cfg.unit}`} onChange={setPeak} />
            {h === "wind" && <p className="text-xs text-muted-foreground">Hypothetical gusts — this does not mean the location is exposed.</p>}
            {h === "cyclone" && <p className="text-xs text-muted-foreground">Hypothetical cyclone, hurricane or typhoon gusts — only relevant where these storms occur. This does not mean the location is exposed.</p>}
            {h === "fire" && <p className="text-xs text-muted-foreground">Exposure stands for ember and radiant-heat load. Vegetation, slope, walls and upgrades shape the result.</p>}
            {h === "heat" && <p className="text-xs text-muted-foreground">Insulation, glazing, orientation, roof colour, shade and paving shape the result.</p>}
          </TabsContent>
          <TabsContent value="upgrades" className="rounded-xl border bg-card p-3">
            <HazardUpgrades hazard={h} />
          </TabsContent>
          <TabsContent value="site" className="space-y-4 rounded-xl border bg-card p-4">
            <p className="text-xs text-muted-foreground">Changes apply to both views.</p>
            {h === "flood" && (<>
              <Select label="Ground relative to street" value={s.site.groundVsStreet} onChange={(v) => upd({ groundVsStreet: v })} options={[{ v: "unknown", l: "Unknown" }, { v: "lower", l: "Lower" }, { v: "level", l: "About level" }, { v: "raised", l: "Raised" }]} />
              <Select label="Drainage after rain" value={s.site.drainage} onChange={(v) => upd({ drainage: v })} options={[{ v: "unknown", l: "Unknown" }, { v: "pools", l: "Water pools" }, { v: "some", l: "Some ponding" }, { v: "free", l: "Drains freely" }]} />
              <Select label="Soil before the event" value={s.site.soilCondition} onChange={(v) => upd({ soilCondition: v })} options={[{ v: "normal", l: "Normal" }, { v: "saturated", l: "Saturated" }]} />
              <RangeField label="Habitable floor above ground" value={s.house.floorHeightM} min={0} max={4} step={0.05} unit="m" format={(v) => `${v.toFixed(2)} m`} onChange={(v) => set((x) => ({ house: { ...x.house, floorHeightM: v } }))} />
            </>)}
            {(h === "heat" || h === "flood") && <RangeField label="Hard surfaces on lot" value={site.hardSurfacePct.value ?? 45} min={0} max={100} step={5} unit="%" onChange={(v) => upd({ hardSurfacePct: v })} />}
            {h === "heat" && <RangeField label="Summer shade over home" value={site.shadePct.value ?? 20} min={0} max={100} step={5} unit="%" onChange={(v) => upd({ shadePct: v })} />}
            {h === "fire" && (<>
              <Select label="Surroundings" value={s.site.surroundings} onChange={(v) => upd({ surroundings: v })} options={[{ v: "unknown", l: "Unknown" }, { v: "urban", l: "Urban" }, { v: "suburban", l: "Suburban" }, { v: "rural", l: "Rural" }, { v: "coastal", l: "Coastal" }, { v: "bushland", l: "Bushland edge" }]} />
              <RangeField label="Distance to vegetation" value={site.vegDistM.value ?? 500} min={0} max={2000} step={10} unit="m" onChange={(v) => upd({ vegDistM: v })} />
              <RangeField label="Slope" value={site.slopeDeg.value ?? 0} min={0} max={30} step={0.5} unit="°" onChange={(v) => upd({ slopeDeg: v })} />
            </>)}
            {(h === "wind" || h === "cyclone") && <Select label="Wind exposure" value={s.site.windExposure} onChange={(v) => upd({ windExposure: v })} options={[{ v: "unknown", l: "Unknown" }, { v: "sheltered", l: "Sheltered" }, { v: "open", l: "Open terrain" }, { v: "hilltop", l: "Hilltop / ridge" }]} />}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function explain(h: Hazard, a: number, b: number, anyOn: boolean, rent: boolean): string {
  if (!anyOn) return `${stressBand(a)} at peak for this ${HAZARD_LABEL[h].toLowerCase()} scenario. Turn on ${HAZARD_LABEL[h].toLowerCase()} upgrades to compare the same event.`;
  const diff = a - b;
  const lead = diff > 0.05 ? `Selected upgrades lower the peak index from ${a.toFixed(1)} to ${b.toFixed(1)} for the same event.` : "Selected upgrades make little difference to this event in the model.";
  return `${lead}${rent ? " Ask your landlord about the changes marked for approval." : ""} Get local professional advice before building work.`;
}
