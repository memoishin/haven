import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useHaven } from "@/lib/haven/state";
import { Flame, ThermometerSun, Tornado, Waves, Wind } from "lucide-react";
import { cn } from "@/lib/utils";
import { COST_SOURCE, costRange, fmtUsd, HAZARD_LABEL, UPGRADES, upgradeGroup, type UpgradeDef } from "@/lib/haven/upgrades";
import type { Hazard } from "@/lib/haven/types";
import { Pill, RangeField } from "./ui";

function fmt(d: UpgradeDef, v: number) {
  if (d.param.labels) return d.param.labels[v - d.param.min] ?? String(v);
  if (d.param.unit === "L") return `${v.toLocaleString()} L`;
  if (d.param.unit === "m") return `${v.toFixed(2)} m`;
  return `${v}${d.param.unit === "%" ? "%" : ` ${d.param.unit}`}`;
}

export function UpgradeCard({ d }: { d: UpgradeDef }) {
  const { s, set } = useHaven();
  const st = s.upgrades[d.id];
  const rent = s.house.mode === "rent";
  const upd = (p: Partial<typeof st>) => set((x) => ({ upgrades: { ...x.upgrades, [d.id]: { ...x.upgrades[d.id], ...p } as typeof st } }));
  const sid = `up-${d.id}`;
  const pl = s.evidence?.priceLevel?.status === "estimate" ? s.evidence.priceLevel.value ?? null : null;
  const [lo, hi] = costRange(d.id, st.value, pl, s.house.type === "apartment");
  return (
    <div className="rounded-xl border bg-card p-3 shadow-sm transition-shadow hover:shadow-md">
      <div className="flex items-center gap-3">
        <label htmlFor={sid} className="min-w-0 flex-1 text-sm font-medium">
          {d.title}
          {rent && d.landlord && <span className="ml-2"><Pill tone="caution">Landlord approval</Pill></span>}
        </label>
        <span className="text-xs tabular-nums text-muted-foreground" title={COST_SOURCE}>{fmtUsd(lo)}–{fmtUsd(hi)}</span>
        <Switch id={sid} checked={st.on} onCheckedChange={(on) => upd({ on })} />
      </div>
      {st.on && (
        <div className="mt-3">
          <RangeField label={d.param.label} value={st.value} min={d.param.min} max={d.param.max} step={d.param.step} unit={d.param.unit} format={(v) => fmt(d, v)} onChange={(value) => upd({ value })} />
        </div>
      )}
      <details className="group mt-1">
        <summary className="min-h-8 py-1 text-xs text-primary">Details</summary>
        <div className="space-y-1 text-xs text-muted-foreground">
          <p>{rent ? d.renter : d.explain}</p>
          {rent && <p>{d.explain}</p>}
          <a className="underline" href={d.guidance.url} target="_blank" rel="noreferrer">{d.guidance.label}</a>
          <span> — check your local building rules.</span>
        </div>
      </details>
    </div>
  );
}

export function HazardUpgrades({ hazard }: { hazard: Hazard }) {
  const { s, set } = useHaven();
  const list = UPGRADES.filter((u) => u.hazard === upgradeGroup(hazard));
  const onCount = list.filter((u) => s.upgrades[u.id].on).length;
  const apply = (fn: (d: UpgradeDef) => boolean) =>
    set((x) => {
      const n = { ...x.upgrades };
      for (const d of list) n[d.id] = { ...n[d.id], on: fn(d) };
      return { upgrades: n };
    });
  return (
    <section className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-semibold">{HAZARD_LABEL[hazard]} <span className="font-normal text-muted-foreground">· {onCount}/{list.length} on</span></h2>
        <div className="flex gap-1">
          <Button variant="outline" size="sm" onClick={() => apply((d) => d.suggested)}>Use suggested</Button>
          <Button variant="ghost" size="sm" onClick={() => apply(() => false)} disabled={onCount === 0}>Clear</Button>
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {list.map((d) => <UpgradeCard key={d.id} d={d} />)}
      </div>
    </section>
  );
}

export function UpgradesStep() {
  const { s, set } = useHaven();
  const hazards: { id: Hazard; label: string; icon: typeof Waves }[] = [
    { id: "flood", label: "Flood", icon: Waves },
    { id: "fire", label: "Fire", icon: Flame },
    { id: "heat", label: "Heat", icon: ThermometerSun },
    { id: "wind", label: "Wind", icon: Wind },
    { id: "cyclone", label: "Cyclone", icon: Tornado },
  ];
  const onAll = UPGRADES.filter((u) => s.upgrades[u.id].on);
  const totalOn = onAll.length;
  const pl = s.evidence?.priceLevel?.status === "estimate" ? s.evidence.priceLevel.value ?? null : null;
  const tot = onAll.reduce<[number, number]>((a, u) => { const [l, h] = costRange(u.id, s.upgrades[u.id].value, pl, s.house.type === "apartment"); return [a[0] + l, a[1] + h]; }, [0, 0]);
  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase text-primary">Step 3 · Upgrades</p>
          <h1 className="font-display text-4xl font-bold">Choose upgrades</h1>
          <p className="text-sm text-muted-foreground">Pick a hazard, then choose what feels practical.</p>
        </div>
        <div className="text-right">
          <Pill tone={totalOn ? "primary" : "muted"}>{totalOn} selected</Pill>
          {totalOn > 0 && <p className="mt-1 text-sm font-semibold tabular-nums">{fmtUsd(tot[0])}–{fmtUsd(tot[1])}</p>}
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5" role="tablist" aria-label="Upgrade type">
        {hazards.map(({ id, label, icon: Icon }) => {
          const count = UPGRADES.filter((u) => u.hazard === upgradeGroup(id) && s.upgrades[u.id].on).length;
          return (
            <Button key={id} type="button" variant={s.hazard === id ? "default" : "outline"} className={cn("h-16 flex-col gap-1 px-2")} onClick={() => set(() => ({ hazard: id }))} role="tab" aria-selected={s.hazard === id}>
              <Icon className="size-5" aria-hidden />
              <span className="text-xs">{label}{count ? ` · ${count}` : ""}</span>
            </Button>
          );
        })}
      </div>
      <HazardUpgrades hazard={s.hazard} />
      <p className="text-[11px] text-muted-foreground">Costs: rough estimate. {COST_SOURCE}{pl ? ` Price level ${pl}× USA.` : ""}</p>
    </div>
  );
}
