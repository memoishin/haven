import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export default function MapPicker({ center, marker, onPick }: { center: [number, number]; marker?: [number, number] | null; onPick: (lat: number, lon: number) => void }) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<L.Map | null>(null);
  const mk = useRef<L.CircleMarker | null>(null);
  const pickRef = useRef(onPick);
  pickRef.current = onPick;

  useEffect(() => {
    if (!el.current || map.current) return;
    const m = L.map(el.current, { worldCopyJump: true }).setView(center, marker ? 13 : 2);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(m);
    m.on("click", (e: L.LeafletMouseEvent) => pickRef.current(e.latlng.lat, ((e.latlng.lng + 540) % 360) - 180));
    map.current = m;
    return () => {
      m.remove();
      map.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const m = map.current;
    if (!m) return;
    if (mk.current) mk.current.remove();
    if (marker) {
      mk.current = L.circleMarker(marker, { radius: 9, color: "#2f6b4a", weight: 3, fillOpacity: 0.3 }).addTo(m);
      m.setView(marker, Math.max(m.getZoom(), 13));
    }
  }, [marker]);

  return <div ref={el} className="h-72 w-full rounded-xl border" role="application" aria-label="Map. Click to select a point." />;
}
