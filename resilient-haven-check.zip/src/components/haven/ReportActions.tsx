import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { FileDown, Link2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { toSnapshot, useHaven } from "@/lib/haven/state";
import { downloadPdf } from "@/lib/haven/report";
import { createShare } from "@/lib/haven/reports.functions";

export function ReportActions() {
  const { s } = useHaven();
  const share = useServerFn(createShare);
  const [busy, setBusy] = useState(false);
  const [link, setLink] = useState<string | null>(null);
  const snap = toSnapshot(s);
  if (!snap) return null;
  const doShare = async () => {
    setBusy(true);
    try {
      const { slug } = await share({ data: { snapshot: snap as unknown as Record<string, unknown> } });
      const url = `${window.location.origin}/r/${slug}`;
      setLink(url);
      await navigator.clipboard?.writeText(url).then(() => toast.success("Link copied"), () => {});
    } catch {
      toast.error("Could not create a share link.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border bg-card p-3">
      <Button variant="outline" className="h-11" onClick={() => downloadPdf(snap)}><FileDown /> PDF report</Button>
      <Button variant="outline" className="h-11" onClick={doShare} disabled={busy}><Link2 /> {busy ? "Creating…" : "Share link"}</Button>
      {link && <input readOnly value={link} onFocus={(e) => e.currentTarget.select()} aria-label="Share link" className="h-11 min-w-0 flex-1 rounded-lg border bg-muted px-3 text-xs" />}
    </div>
  );
}
