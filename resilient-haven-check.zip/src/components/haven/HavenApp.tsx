import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, ArrowRight, HousePlus, MapPin, ShieldPlus, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { HavenProvider, useHaven } from "@/lib/haven/state";
import { getPhotos, getSiteEvidence } from "@/lib/haven/providers.functions";
import type { Photo } from "@/lib/haven/types";
import { autoHouse, presetsFor } from "@/lib/haven/model";
import { AboutDialog, MethodDialog } from "./Dialogs";
import { AccountDialog } from "./Account";
import { AddressStep } from "./AddressStep";
import { LocationBar } from "./LocationBar";
import { ProfileStep } from "./ProfileStep";
import { UpgradesStep } from "./UpgradesPanel";
import { SimulateStep } from "./SimulateStep";
import { cn } from "@/lib/utils";

const STEPS = [
  { name: "Address", icon: MapPin },
  { name: "Profile", icon: HousePlus },
  { name: "Upgrades", icon: ShieldPlus },
  { name: "Compare", icon: SlidersHorizontal },
];

export function HavenApp() {
  return (
    <HavenProvider>
      <Shell />
    </HavenProvider>
  );
}

function Shell() {
  const { s, set, load } = useHaven();
  // Open a shared report handed over from /r/$slug.
  useEffect(() => {
    const raw = sessionStorage.getItem("haven:open");
    if (!raw) return;
    sessionStorage.removeItem("haven:open");
    try { load(JSON.parse(raw)); } catch { /* ignore malformed */ }
  }, [load]);
  const fetchEvidence = useServerFn(getSiteEvidence);
  const fetchPhotos = useServerFn(getPhotos);
  const [photos, setPhotos] = useState<{ examples: Photo[]; nearby: Photo[] }>({ examples: [], nearby: [] });
  const [photosLoading, setPhotosLoading] = useState(false);
  const reqId = useRef(0);
  const main = useRef<HTMLElement>(null);

  // Evidence: fetch whenever status is "loading" (new place or refresh). Stale responses are dropped.
  useEffect(() => {
    if (!s.place || s.evidenceStatus !== "loading") return;
    const id = ++reqId.current;
    const { lat, lon, countryCode } = s.place;
    fetchEvidence({ data: { lat, lon, ...(countryCode ? { countryCode } : {}) } })
      .then((ev) => {
        if (id !== reqId.current) return;
        set((x) => {
          // Auto-fill house fields the user hasn't edited, and set event levels from local records.
          const ah = autoHouse(ev);
          const house = { ...x.house };
          const houseAuto: string[] = [];
          for (const k of Object.keys(ah) as (keyof typeof ah)[]) {
            if (x.houseEdited.includes(k)) continue;
            (house as Record<string, unknown>)[k] = ah[k];
            houseAuto.push(k);
          }
          const intensity = { ...x.intensity };
          for (const h of ["heat", "wind"] as const) {
            const p = presetsFor(h, ev);
            if (p.local) intensity[h] = p.values[1];
          }
          return { evidence: ev, evidenceStatus: "ready", house, houseAuto, intensity };
        });
      })
      .catch(() => { if (id === reqId.current) set(() => ({ evidenceStatus: "error" })); });
  }, [s.place, s.evidenceStatus, fetchEvidence, set]);

  // Photos for the place; default to example matching house type (never auto-pick a nearby photo as "this house").
  useEffect(() => {
    if (!s.place) return;
    let live = true;
    setPhotosLoading(true);
    setPhotos({ examples: [], nearby: [] });
    fetchPhotos({ data: { lat: s.place.lat, lon: s.place.lon, houseType: s.house.type } })
      .then((r) => {
        if (!live) return;
        setPhotos(r);
        const ex = r.examples[0];
        if (ex) set((x) => (x.photo ? {} : { photo: ex }));
      })
      .catch(() => live && setPhotos({ examples: [], nearby: [] }))
      .finally(() => live && setPhotosLoading(false));
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.place]);

  const go = (n: number) => {
    set(() => ({ step: n }));
    requestAnimationFrame(() => { window.scrollTo({ top: 0 }); main.current?.focus({ preventScroll: true }); });
  };
  const has = !!s.place;

  return (
    <div className="min-h-screen pb-28">
      <header className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-3 gap-y-1 px-4 pt-5">
        <span className="font-display text-3xl font-bold text-foreground">Haven<span className="text-primary">.</span></span>
        <span className="rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">Resilient Cities &amp; Buildings</span>
        <nav className="ml-auto flex">
          <MethodDialog />
          <AboutDialog />
          <AccountDialog />
        </nav>
      </header>

      <nav aria-label="Steps" className="mx-auto mt-5 max-w-6xl px-4">
        <ol className="flex gap-2 overflow-x-auto rounded-xl border bg-card p-2 shadow-sm">
          {STEPS.map(({ name, icon: Icon }, i) => {
            const cur = s.step === i;
            const enabled = i === 0 || has;
            return (
              <li key={name} className="flex-1">
                <button
                  onClick={() => enabled && go(i)}
                  disabled={!enabled}
                  aria-current={cur ? "step" : undefined}
                  className={cn("flex w-full min-w-20 flex-col gap-1.5 rounded-lg px-2 py-2 text-left text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-40", cur ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-muted")}
                >
                  <span className={cn("h-1 w-full rounded-full", cur ? "bg-primary" : i < s.step && has ? "bg-caution" : "bg-border")} />
                  <span className="flex items-center gap-1.5"><Icon className="size-3.5" aria-hidden />{name}</span>
                </button>
              </li>
            );
          })}
        </ol>
      </nav>

      <main ref={main} tabIndex={-1} className="mx-auto mt-4 max-w-6xl space-y-4 px-4 focus:outline-none">
        {s.step > 0 && <LocationBar />}
        {s.step === 0 && <AddressStep />}
        {s.step === 1 && has && <ProfileStep photos={photos} photosLoading={photosLoading} onCompare={() => go(3)} />}
        {s.step === 2 && has && <UpgradesStep />}
        {s.step === 3 && has && <SimulateStep />}
      </main>

      {s.step > 0 && (
        <div className="fixed inset-x-0 bottom-0 border-t bg-background/95 backdrop-blur">
          <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-3">
            <Button variant="outline" className="h-11" onClick={() => go(s.step - 1)}><ArrowLeft /> Back</Button>
            <span className="text-xs text-muted-foreground">{STEPS[s.step]?.name} · {s.step + 1}/4</span>
            {s.step < 3 ? (
              <Button className="h-11" onClick={() => go(s.step + 1)}>Continue <ArrowRight /></Button>
            ) : (
              <Button variant="outline" className="h-11" onClick={() => go(2)}>Edit upgrades</Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
