import { useMemo } from "react";
import { Flame, Home, ThermometerSun, Tornado, Waves, Wind } from "lucide-react";
import { Button } from "@/components/ui/button";
import { computeResult, effectiveSite } from "@/lib/haven/model";
import type { Hazard, Photo } from "@/lib/haven/types";
import { HAZARD_LABEL } from "@/lib/haven/upgrades";
import { useHaven } from "@/lib/haven/state";
import { HouseStep } from "./HouseStep";
import { SimView } from "./SimView";
import { SiteStep } from "./SiteStep";

const HAZARDS: { id: Hazard; icon: typeof Waves; short: string }[] = [
  { id: "flood", icon: Waves, short: "Flood" },
  { id: "fire", icon: Flame, short: "Fire" },
  { id: "heat", icon: ThermometerSun, short: "Heat" },
  { id: "wind", icon: Wind, short: "Wind" },
  { id: "cyclone", icon: Tornado, short: "Cyclone" },
];

export function ProfileStep({ photos, photosLoading, onCompare }: { photos: { examples: Photo[]; nearby: Photo[] }; photosLoading: boolean; onCompare: () => void }) {
  const { s, set } = useHaven();
  const site = useMemo(() => effectiveSite(s.site, s.evidence), [s.site, s.evidence]);
  const peak = s.intensity[s.hazard];
  const result = computeResult(s.hazard, peak, s.floodKind, s.house, site, s.upgrades, false);

  return (
    <div className="space-y-8">
      <div className="rounded-xl bg-primary px-5 py-6 text-primary-foreground shadow-md">
        <p className="text-xs font-semibold uppercase text-primary-foreground/80">Step 2 · Profile</p>
        <h1 className="font-display text-4xl font-bold">Property profile</h1>
        <p className="text-sm text-primary-foreground/85">Review the site, home and a current-house scenario.</p>
      </div>

      <section className="space-y-3 rounded-xl bg-caution/35 p-4 sm:p-5" aria-labelledby="current-scenario">
        <div className="flex items-center gap-2">
          <Home className="size-5 text-primary" aria-hidden />
          <h2 id="current-scenario" className="text-base font-semibold">Current house scenario</h2>
        </div>
        <div className="grid grid-cols-4 gap-2" role="tablist" aria-label="Choose hazard">
          {HAZARDS.map(({ id, icon: Icon, short }) => (
            <Button key={id} type="button" variant={s.hazard === id ? "default" : "outline"} className="h-14 flex-col gap-1 px-2" onClick={() => set(() => ({ hazard: id }))} role="tab" aria-selected={s.hazard === id}>
              <Icon className="size-4" aria-hidden />
              <span className="text-xs">{short}</span>
            </Button>
          ))}
        </div>
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_220px]">
          <SimView photo={s.photo} calib={s.calib} hazard={s.hazard} floodKind={s.floodKind} current={peak} level={1} stress={result.stress} floorM={s.house.floorHeightM} addedM={0} badge="Current house" />
          <div className="flex flex-col justify-between gap-3 rounded-lg border border-primary/20 bg-card p-4 shadow-md">
            <div>
              <p className="text-xs text-muted-foreground">Illustrative scenario</p>
              <p className="mt-1 text-lg font-semibold">{HAZARD_LABEL[s.hazard]}</p>
              <p className="mt-3 font-display text-4xl tabular-nums">{result.stress.toFixed(1)}<span className="font-sans text-sm text-muted-foreground"> / 10</span></p>
              <p className="mt-1 text-xs text-muted-foreground">Stress index, not a safety score.</p>
            </div>
            <Button type="button" variant="outline" onClick={onCompare}>Open simulation</Button>
          </div>
        </div>
      </section>

      <div className="grid gap-8 border-t pt-8">
        <SiteStep compact />
        <div className="border-t pt-8"><HouseStep photos={photos} photosLoading={photosLoading} compact /></div>
      </div>
    </div>
  );
}