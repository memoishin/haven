import type { ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

export function Select<T extends string>({ label, value, options, onChange, hint }: { label: string; value: T; options: { v: T; l: string }[]; onChange: (v: T) => void; hint?: string }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="font-medium">{label}</span>
      <select
        className="h-11 rounded-lg border border-input bg-card px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
      >
        {options.map((o) => (
          <option key={o.v} value={o.v}>
            {o.l}
          </option>
        ))}
      </select>
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
}

export function RangeField({ label, value, min, max, step, unit, onChange, format, tag }: { label: string; value: number; min: number; max: number; step: number; unit: string; onChange: (v: number) => void; format?: (v: number) => string; tag?: ReactNode }) {
  return (
    <div className="flex flex-col gap-2 text-sm">
      <div className="flex items-center justify-between gap-2">
        <span className="font-medium">{label}</span>
        <span className="flex items-center gap-2 tabular-nums text-muted-foreground">
          {tag}
          {format ? format(value) : `${value} ${unit}`}
        </span>
      </div>
      <Slider aria-label={label} value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0] ?? value)} className="py-2" />
    </div>
  );
}

export function NumberField({ label, value, unit, onChange, min, max, step = 0.1 }: { label: string; value: number | null; unit: string; onChange: (v: number | null) => void; min: number; max: number; step?: number }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="font-medium">
        {label} <span className="font-normal text-muted-foreground">({unit})</span>
      </span>
      <input
        type="number"
        inputMode="decimal"
        min={min}
        max={max}
        step={step}
        placeholder="Leave blank to use public estimate"
        value={value ?? ""}
        onChange={(e) => {
          const raw = e.target.value;
          if (raw === "") return onChange(null);
          const n = Number(raw);
          if (Number.isFinite(n)) onChange(Math.min(max, Math.max(min, n)));
        }}
        className="h-11 rounded-lg border border-input bg-card px-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      />
    </label>
  );
}

export function Expand({ title, children, defaultOpen, className }: { title: ReactNode; children: ReactNode; defaultOpen?: boolean; className?: string }) {
  return (
    <details open={defaultOpen} className={cn("group rounded-xl border bg-card", className)}>
      <summary className="flex min-h-11 items-center justify-between gap-2 px-4 py-2 text-sm font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-xl">
        {title}
        <ChevronDown className="size-4 shrink-0 transition-transform group-open:rotate-180" aria-hidden />
      </summary>
      <div className="border-t px-4 py-3 text-sm">{children}</div>
    </details>
  );
}

export function Pill({ children, tone = "muted" }: { children: ReactNode; tone?: "muted" | "evidence" | "user" | "caution" | "primary" }) {
  const t = {
    muted: "bg-muted text-muted-foreground",
    evidence: "bg-evidence text-foreground",
    user: "bg-user text-foreground",
    caution: "bg-caution text-caution-foreground",
    primary: "bg-primary text-primary-foreground",
  }[tone];
  return <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium whitespace-nowrap", t)}>{children}</span>;
}

export function Segmented<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: { v: T; l: string }[]; onChange: (v: T) => void }) {
  return (
    <div role="radiogroup" aria-label={label} className="inline-flex rounded-xl border bg-muted p-1">
      {options.map((o) => (
        <button
          key={o.v}
          role="radio"
          aria-checked={value === o.v}
          onClick={() => onChange(o.v)}
          className={cn("min-h-10 rounded-lg px-4 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", value === o.v ? "bg-card shadow-sm" : "text-muted-foreground hover:text-foreground")}
        >
          {o.l}
        </button>
      ))}
    </div>
  );
}
