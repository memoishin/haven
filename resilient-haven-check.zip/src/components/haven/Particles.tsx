import { useEffect, useRef } from "react";

export type ParticleMode = "rain" | "embers" | "wind" | "none";

interface P { x: number; y: number; vx: number; vy: number; life: number; s: number }

/** Lightweight canvas particle layer. Intensity 0..1. Static frame under reduced motion. */
export function Particles({ mode, intensity }: { mode: ParticleMode; intensity: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const iRef = useRef(intensity);
  iRef.current = intensity;

  useEffect(() => {
    const c = ref.current;
    if (!c || mode === "none") return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const css = getComputedStyle(c);
    const ember = css.getPropertyValue("--ember").trim() || "orange";
    const windC = css.getPropertyValue("--wind").trim() || "white";
    let w = 0, h = 0, raf = 0;
    const ps: P[] = [];
    const resize = () => {
      const r = c.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      w = r.width; h = r.height;
      c.width = w * dpr; c.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(c);
    const spawn = (): P => {
      if (mode === "rain") return { x: Math.random() * w * 1.2, y: -10, vx: -1.5, vy: 9 + Math.random() * 5, life: 1, s: 8 + Math.random() * 8 };
      if (mode === "wind") return { x: -40, y: Math.random() * h, vx: 14 + Math.random() * 10, vy: 1.5 + Math.random() * 2, life: 1, s: 20 + Math.random() * 40 };
      return { x: Math.random() * w, y: h + 5, vx: 0.6 + Math.random() * 1.2, vy: -(1 + Math.random() * 2), life: 1, s: 1 + Math.random() * 2.2 };
    };
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      const k = iRef.current;
      const target = Math.round((mode === "embers" ? 90 : mode === "wind" ? 70 : 160) * k);
      while (ps.length < target) ps.push(spawn());
      if (ps.length > target) ps.length = target;
      for (let i = 0; i < ps.length; i++) {
        const p = ps[i]!;
        if (!reduced) {
          p.x += p.vx * (mode === "wind" ? 0.6 + k : 1);
          p.y += p.vy;
          if (mode === "embers") { p.vx += (Math.random() - 0.5) * 0.2; p.life -= 0.004; }
        }
        if (p.y > h + 20 || p.x > w + 60 || p.y < -20 || p.life <= 0) { const np = spawn(); if (reduced) { np.x = Math.random() * w; np.y = Math.random() * h; } ps[i] = np; continue; }
        if (mode === "rain") {
          ctx.strokeStyle = "rgba(220,235,245,0.55)"; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + p.vx * 1.5, p.y + p.s); ctx.stroke();
        } else if (mode === "wind") {
          ctx.strokeStyle = windC; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + p.s, p.y + p.s * 0.12); ctx.stroke(); ctx.globalAlpha = 1;
        } else {
          ctx.fillStyle = ember; ctx.globalAlpha = Math.max(0, p.life) * (0.6 + Math.random() * 0.4);
          ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
        }
      }
      if (!reduced) raf = requestAnimationFrame(draw);
    };
    if (reduced) { for (let i = 0; i < 60; i++) { const p = spawn(); p.x = Math.random() * w; p.y = Math.random() * h; ps.push(p); } }
    draw();
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [mode]);

  if (mode === "none") return null;
  return <canvas ref={ref} aria-hidden className="pointer-events-none absolute inset-0 h-full w-full" />;
}
