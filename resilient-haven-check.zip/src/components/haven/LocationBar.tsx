import { MapPin } from "lucide-react";
import { useHaven } from "@/lib/haven/state";
import type { Precision } from "@/lib/haven/types";
import { Pill } from "./ui";

export const PRECISION_LABEL: Record<Precision, string> = {
  address: "Address / building",
  street: "Approximate street",
  locality: "Locality centre",
  manual: "Manually selected point",
};

export function LocationBar() {
  const { s, set } = useHaven();
  if (!s.place) return null;
  const p = s.place;
  return (
    <div className="flex items-center gap-2 rounded-xl border border-primary/20 bg-secondary/70 px-3 py-2 text-sm shadow-sm">
      <MapPin className="size-4 shrink-0 text-primary" aria-hidden />
      <div className="min-w-0 flex-1">
        <div className="truncate font-medium">{p.label.split(",").slice(0, 2).join(",")}</div>
        <div className="truncate text-xs text-muted-foreground">
          {[p.region, p.country].filter(Boolean).join(" · ") || "Country unknown"} · {p.lat.toFixed(4)}, {p.lon.toFixed(4)}
        </div>
      </div>
      <Pill tone={p.precision === "address" ? "evidence" : "caution"}>{PRECISION_LABEL[p.precision]}</Pill>
      <button onClick={() => set(() => ({ step: 0 }))} className="min-h-9 rounded-lg px-2 text-xs font-medium text-primary underline-offset-2 hover:underline">
        Change
      </button>
    </div>
  );
}
