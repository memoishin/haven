import { useEffect, useState } from "react";
import { BookmarkPlus, FolderOpen, LogOut, Trash2, UserRound } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { toSnapshot, useHaven, type Snapshot } from "@/lib/haven/state";
import type { User } from "@supabase/supabase-js";

export function useUser() {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((_e, session) => setUser(session?.user ?? null));
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  return user;
}

function SignInForm({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
      if (error) setMsg(error.message);
      else onDone();
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: window.location.origin } });
      if (error) setMsg(error.message);
      else if (!data.session) setMsg("Check your email to confirm your account, then sign in.");
      else onDone();
    }
    setBusy(false);
  };
  const google = async () => {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) setMsg(r.error.message ?? "Google sign-in failed.");
    else if (!r.redirected) onDone();
  };
  return (
    <div className="space-y-4">
      <Button variant="outline" className="h-11 w-full" onClick={google}>Continue with Google</Button>
      <div className="text-center text-xs text-muted-foreground">or</div>
      <form onSubmit={submit} className="space-y-3">
        <input type="email" required placeholder="Email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 w-full rounded-lg border bg-card px-3" />
        <input type="password" required minLength={8} placeholder="Password (8+ characters)" autoComplete={mode === "in" ? "current-password" : "new-password"} value={pw} onChange={(e) => setPw(e.target.value)} className="h-11 w-full rounded-lg border bg-card px-3" />
        {msg && <p className="text-sm text-muted-foreground" role="status">{msg}</p>}
        <Button type="submit" className="h-11 w-full" disabled={busy}>{mode === "in" ? "Sign in" : "Create account"}</Button>
      </form>
      <button type="button" className="w-full text-center text-xs text-primary underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
        {mode === "in" ? "New here? Create an account" : "Have an account? Sign in"}
      </button>
    </div>
  );
}

interface Row { id: string; name: string; updated_at: string; snapshot: unknown }

function MyPlaces({ user, onClose }: { user: User; onClose: () => void }) {
  const { s, load } = useHaven();
  const [rows, setRows] = useState<Row[] | null>(null);
  const refresh = () =>
    supabase.from("saved_properties").select("id,name,updated_at,snapshot").order("updated_at", { ascending: false }).then(({ data, error }) => {
      if (error) toast.error("Could not load your places.");
      setRows((data as Row[]) ?? []);
    });
  useEffect(() => { void refresh(); }, []);
  const save = async () => {
    const snap = toSnapshot(s);
    if (!snap) return;
    const name = snap.place.locality ? `${snap.place.locality}${snap.place.country ? `, ${snap.place.country}` : ""}` : snap.place.label.slice(0, 120);
    const { error } = await supabase.from("saved_properties").insert({ user_id: user.id, name, snapshot: snap as never });
    if (error) toast.error("Could not save.");
    else { toast.success("Saved"); void refresh(); }
  };
  const del = async (id: string) => {
    await supabase.from("saved_properties").delete().eq("id", id);
    void refresh();
  };
  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">Signed in as {user.email}</p>
      <Button className="h-11 w-full" onClick={save} disabled={!s.place}><BookmarkPlus /> Save current place</Button>
      <ul className="space-y-2">
        {rows === null && <li className="text-sm text-muted-foreground">Loading…</li>}
        {rows?.length === 0 && <li className="text-sm text-muted-foreground">No saved places yet.</li>}
        {rows?.map((r) => (
          <li key={r.id} className="flex items-center gap-2 rounded-lg border p-2">
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-medium">{r.name}</div>
              <div className="text-[11px] text-muted-foreground">{new Date(r.updated_at).toLocaleDateString()}</div>
            </div>
            <Button size="sm" variant="outline" onClick={() => { load(r.snapshot as Snapshot); onClose(); }}><FolderOpen /> Open</Button>
            <Button size="icon" variant="ghost" aria-label={`Delete ${r.name}`} onClick={() => del(r.id)}><Trash2 /></Button>
          </li>
        ))}
      </ul>
      <Button variant="ghost" size="sm" onClick={() => supabase.auth.signOut()}><LogOut /> Sign out</Button>
    </div>
  );
}

export function AccountDialog() {
  const user = useUser();
  const [open, setOpen] = useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm"><UserRound /> {user ? "My places" : "Sign in"}</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">{user ? "My places" : "Sign in to save places"}</DialogTitle>
        </DialogHeader>
        {user ? <MyPlaces user={user} onClose={() => setOpen(false)} /> : <SignInForm onDone={() => {}} />}
        {!user && <p className="text-xs text-muted-foreground">Optional — Haven works without an account.</p>}
      </DialogContent>
    </Dialog>
  );
}
