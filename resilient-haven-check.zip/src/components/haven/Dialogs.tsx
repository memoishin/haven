import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-1.5">
      <h3 className="text-sm font-semibold">{title}</h3>
      <div className="space-y-1.5 text-sm text-muted-foreground">{children}</div>
    </section>
  );
}

export function AboutDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">About</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl font-normal">About Haven</DialogTitle>
        </DialogHeader>
        <div className="space-y-5">
          <Section title="Challenge">
            <p>Primary priority: Resilient Cities &amp; Buildings. Secondary: climate awareness and education.</p>
          </Section>
          <Section title="Who it’s for">
            <p>People planning a new house, homeowners considering renovations, and people comparing rentals — anywhere in the world.</p>
          </Section>
          <Section title="The barrier">
            <p>Climate information is scattered, technical and hard to connect to one home or one building decision.</p>
          </Section>
          <Section title="How it works">
            <ul className="list-disc space-y-1 pl-5">
              <li>Find a place by address, map point or coordinates.</li>
              <li>See public estimates for elevation, terrain, soil, waterways, coast and vegetation — each with source and limits.</li>
              <li>Describe the house, then try 20 upgrades across flood, fire, heat and wind.</li>
              <li>Run the same event before and after upgrades on a real, openly licensed photograph.</li>
            </ul>
          </Section>
          <Section title="Why it supports resilient buildings">
            <p>It helps people ask better questions earlier — at design, renovation or lease stage — when resilience and efficiency changes are cheapest. Heat upgrades (shading, insulation, glazing, cool roofs) overlap with the challenge’s building-energy reduction goal; this is an intended contribution, not a saving measured by this prototype.</p>
          </Section>
          <Section title="Functional in this prototype">
            <ul className="list-disc space-y-1 pl-5">
              <li>Worldwide geocoding, map selection and coordinate entry.</li>
              <li>Live elevation, slope, soil and OpenStreetMap proximity lookups.</li>
              <li>Wikimedia Commons photographs with attribution and match labelling.</li>
              <li>Deterministic teaching model with 20 adjustable upgrades and animated comparisons.</li>
            </ul>
          </Section>
          <Section title="Needs validation before advisory use">
            <ul className="list-disc space-y-1 pl-5">
              <li>Model factors reviewed by engineers, fire and flood specialists.</li>
              <li>Integration of authoritative local flood, fire and wind maps per country.</li>
              <li>Accessibility and comprehension testing with diverse users.</li>
            </ul>
          </Section>
          <Section title="Pilot plan">
            <p>Test with around 20 renters, homeowners and prospective builders. Before and after using Haven, measure whether they can: identify relevant hazards; distinguish evidence from assumptions; explain feasible improvements; and recognise when local professional advice is needed.</p>
          </Section>
          <Section title="Route to real-world use">
            <p>Partner with councils, community organisations, housing providers and qualified building professionals to add local data, review guidance and connect users to trusted advice.</p>
          </Section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function MethodDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">Data &amp; method</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl font-normal">Data &amp; method</DialogTitle>
        </DialogHeader>
        <div className="space-y-5">
          <Section title="Connected public sources">
            <ul className="list-disc space-y-1 pl-5">
              <li>OpenStreetMap Nominatim — geocoding (ODbL; max 1 request/s, cached).</li>
              <li>OpenStreetMap tiles — map display.</li>
              <li>Overpass API — mapped waterways, coastline, woodland/forest/scrub (ODbL).</li>
              <li>Open-Meteo Elevation API — Copernicus DEM GLO-90, ~90 m (CC BY 4.0).</li>
              <li>ISRIC SoilGrids 2.0 — topsoil clay/sand/silt, 250 m (CC BY 4.0).</li>
              <li>Wikimedia Commons — openly licensed photographs, credited per image.</li>
            </ul>
          </Section>
          <Section title="Evidence labels">
            <p><strong>Public estimate</strong>: remote, modelled or mapped data. <strong>Your input</strong>: overrides used by the model; the original estimate is kept. <strong>Data unavailable</strong>: the provider failed or has no coverage — never treated as low risk.</p>
          </Section>
          <Section title="The teaching model">
            <p>Deterministic formulas in one inspectable module. Flood uses: water above floor = max(0, water depth − floor height − added floor height). Water depth is measured from local ground, never from sea level.</p>
            <p>Other hazards produce an <strong>Illustrative stress index (0–10)</strong>: 0 = minimal modelled stress, 10 = highest modelled stress. It compares the same event before and after upgrades. It is not a probability, damage percentage or safety rating.</p>
            <p>Upgrade coverage is how much of the work is done, not a protection probability. Upgrades already present in the house are not counted twice. Paving, drainage and storage only affect the surface-water comparison.</p>
          </Section>
          <Section title="Limitations">
            <ul className="list-disc space-y-1 pl-5">
              <li>Elevation and waterway distance cannot establish flood depth without hydraulic modelling.</li>
              <li>No global parcel-level hazard data exists here; check local official hazard maps.</li>
              <li>No building standard is applied; guidance links are examples from specific countries.</li>
              <li>Photos cannot show structural condition or construction quality.</li>
            </ul>
          </Section>
          <Section title="Remaining integrations">
            <ul className="list-disc space-y-1 pl-5">
              <li>National flood, wildfire and wind maps through the modular provider layer.</li>
              <li>Climate reanalysis (e.g. ERA5) for local heat and wind history.</li>
              <li>Mapped building footprints for exact-building photo linkage.</li>
            </ul>
          </Section>
        </div>
      </DialogContent>
    </Dialog>
  );
}
