import { useMemo } from "react";
import { Building2, Droplets, Globe2, Mountain, RefreshCw, Trees, Waves, Layers, TrendingUp, ThermometerSun, Wind, CalendarClock, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useHaven } from "@/lib/haven/state";
import { effectiveSite, fmtDist, screeningNotes, type Val } from "@/lib/haven/model";
import type { Evidence, SiteInputs } from "@/lib/haven/types";
import { HAZARD_LABEL } from "@/lib/haven/upgrades";
import { Expand, NumberField, Pill, RangeField, Select } from "./ui";

function originPill(o: Val<unknown>["origin"]) {
  if (o === "user") return <Pill tone="user">Your input</Pill>;
  if (o === "evidence") return <Pill tone="evidence">Public estimate</Pill>;
  if (o === "assumed") return <Pill tone="caution">Assumption</Pill>;
  return <Pill>Data unavailable</Pill>;
}

function Card({ icon: Icon, title, value, origin, ev, loading, extra }: { icon: typeof Globe2; title: string; value: string; origin: Val<unknown>["origin"]; ev?: Evidence<unknown> | undefined; loading?: boolean; extra?: string | undefined }) {
  return (
    <details className="group rounded-xl border bg-card">
      <summary className="flex min-h-16 items-center gap-3 rounded-xl px-3 py-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
        <Icon className="size-5 shrink-0 text-primary" aria-hidden />
        <div className="min-w-0 flex-1">
          <div className="text-xs text-muted-foreground">{title}</div>
          <div className="truncate text-sm font-semibold">{loading ? <span className="inline-block h-4 w-20 animate-pulse rounded bg-muted" /> : value}</div>
        </div>
        {!loading && originPill(origin)}
      </summary>
      <div className="space-y-1 border-t px-3 py-2 text-xs text-muted-foreground">
        {extra && <p>{extra}</p>}
        {ev ? (
          <>
            {origin === "user" && <p className="text-foreground">You overrode this. Original public value kept below.</p>}
            {ev.note && <p>{ev.note}</p>}
            <p><span className="font-medium text-foreground">Source:</span> {ev.sourceUrl ? <a className="underline" href={ev.sourceUrl} target="_blank" rel="noreferrer">{ev.source}</a> : ev.source}</p>
            {ev.licence && <p><span className="font-medium text-foreground">Licence:</span> {ev.licence}</p>}
            <p><span className="font-medium text-foreground">Retrieved:</span> {new Date(ev.retrieved).toLocaleString()} for {ev.lat.toFixed(4)}, {ev.lon.toFixed(4)}</p>
            {ev.resolution && <p><span className="font-medium text-foreground">Resolution:</span> {ev.resolution}</p>}
            {ev.unit && <p><span className="font-medium text-foreground">Units:</span> {ev.unit}</p>}
            <p><span className="font-medium text-foreground">Limits:</span> {ev.limitations}</p>
          </>
        ) : (
          !loading && <p>No source record.</p>
        )}
      </div>
    </details>
  );
}

export function SiteStep({ compact = false }: { compact?: boolean }) {
  const { s, set } = useHaven();
  const ev = s.evidence;
  const loading = s.evidenceStatus === "loading";
  const eff = useMemo(() => effectiveSite(s.site, ev), [s.site, ev]);
  const upd = (p: Partial<SiteInputs>) => set((st) => ({ site: { ...st.site, ...p } }));
  const p = s.place;
  if (!p) return null;
  const dist = (v: Val<number>) => (v.value == null ? "Data unavailable" : v.beyond ? `None mapped within ${fmtDist(v.value)}` : fmtDist(v.value));
  const soilVal = ev?.soil.value;
  const notes = screeningNotes(eff, ev);
  const clim = ev?.climate?.status === "estimate" ? ev.climate.value : undefined;
  const fut = ev?.future?.status === "estimate" ? ev.future.value : undefined;
  const river = ev?.river?.status === "estimate" ? ev.river.value : undefined;
  const bld = ev?.buildings?.status === "estimate" ? ev.buildings.value : undefined;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          {compact ? <h2 className="font-display text-3xl">Site profile</h2> : <h1 className="font-display text-4xl">The site</h1>}
          {!compact && <p className="text-sm text-muted-foreground">Ground, soil and surroundings — before the house.</p>}
        </div>
        <Button variant="outline" size="sm" onClick={() => set(() => ({ evidenceStatus: "loading", evidence: null }))} disabled={loading} aria-label="Refresh public data">
          <RefreshCw className={loading ? "animate-spin" : ""} /> Refresh
        </Button>
      </div>
      {s.evidenceStatus === "error" && <p className="rounded-lg bg-caution px-3 py-2 text-sm text-caution-foreground">Public data could not be loaded. You can continue with your own inputs.</p>}

      <section className="space-y-2">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Location</h2>
        <div className="grid gap-2 sm:grid-cols-2">
          <Card icon={Globe2} title="Country & region" value={[p.region, p.country].filter(Boolean).join(", ") || "Unknown"} origin={p.country ? "evidence" : "unavailable"} extra={`${p.source}. Country is context only — it does not set hazard levels.`} />
          <Card icon={Mountain} title="Ground elevation" value={eff.elevationM.value != null ? `${eff.elevationM.value} m above sea level` : "Data unavailable"} origin={eff.elevationM.origin} ev={ev?.elevation} loading={loading} />
          <Card icon={TrendingUp} title="Surrounding slope" value={eff.slopeDeg.value != null ? `${eff.slopeDeg.value}° ${eff.slopeDeg.value < 2 ? "· flat" : eff.slopeDeg.value < 6 ? "· gentle" : "· steep"}` : "Data unavailable"} origin={eff.slopeDeg.origin} ev={ev?.slope} loading={loading} />
          <Card icon={Layers} title="Soil (topsoil)" value={eff.soilTexture.origin === "user" ? `${s.site.soilTexture} (observed)` : soilVal ? `${soilVal.clayPct}% clay · ${soilVal.texture}` : "Data unavailable"} origin={eff.soilTexture.origin} ev={ev?.soil} loading={loading} />
        </div>
      </section>

      <section className="space-y-2">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Surroundings</h2>
        <div className="grid gap-2 sm:grid-cols-3">
          <Card icon={Droplets} title="Nearest waterway" value={dist(eff.waterDistM)} origin={eff.waterDistM.origin} ev={ev?.waterway} loading={loading} extra={ev?.waterway.value ? `${ev.waterway.value.name ?? "Unnamed"} (${ev.waterway.value.kind})` : undefined} />
          <Card icon={Waves} title="Nearest coastline" value={dist(eff.coastDistM)} origin={eff.coastDistM.origin} ev={ev?.coast} loading={loading} />
          <Card icon={Trees} title="Nearest woodland / scrub" value={dist(eff.vegDistM)} origin={eff.vegDistM.origin} ev={ev?.vegetation} loading={loading} extra={ev?.vegetation.value ? `Mapped as ${ev.vegetation.value.kind}` : undefined} />
        </div>
      </section>

      <section className="space-y-2">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Climate records</h2>
        <div className="grid gap-2 sm:grid-cols-2">
          <Card icon={ThermometerSun} title={`Hottest days ${clim?.period ?? ""}`} value={clim ? `Record ${clim.tmaxRecord} °C · ${clim.hotDays35PerYr} days/yr ≥ 35 °C` : "Data unavailable"} origin={clim ? "evidence" : "unavailable"} ev={ev?.climate} loading={loading} />
          <Card icon={CalendarClock} title={`Future heat ${fut ? fut.futurePeriod : ""}`} value={fut ? `${fut.hotDays35Base} → ${fut.hotDays35Future} days/yr ≥ 35 °C` : "Data unavailable"} origin={fut ? "evidence" : "unavailable"} ev={ev?.future} loading={loading} extra={fut ? `Model ${fut.model}: ${fut.basePeriod} vs ${fut.futurePeriod}.` : undefined} />
          <Card icon={Wind} title={`Strongest gusts ${clim?.period ?? ""}`} value={clim ? `Record ${clim.gustRecord} km/h · storm day ${clim.gustP99} km/h` : "Data unavailable"} origin={clim ? "evidence" : "unavailable"} ev={ev?.climate} loading={loading} />
          <Card icon={Activity} title="River flow nearby" value={river ? `Peak ${river.maxM3s.toLocaleString()} m³/s (${river.maxDate.slice(0, 4)}) · usual ${river.medianM3s} m³/s` : ev?.river?.status === "none-found" ? "No large river modelled" : "Data unavailable"} origin={river || ev?.river?.status === "none-found" ? "evidence" : "unavailable"} ev={ev?.river} loading={loading} extra={river ? `Peak flow was ${river.medianM3s > 0 ? Math.round(river.maxM3s / river.medianM3s) : "—"}× the usual flow.` : undefined} />
          <Card icon={Building2} title="Surroundings" value={`${eff.inputs.surroundings === "unknown" ? "Unknown" : eff.inputs.surroundings[0]!.toUpperCase() + eff.inputs.surroundings.slice(1)}${bld ? ` · ${bld.count300m} buildings within 300 m` : ""}`} origin={eff.auto.includes("surroundings") ? "evidence" : s.site.surroundings !== "unknown" ? "user" : "unavailable"} ev={ev?.buildings} loading={loading} extra={eff.auto.includes("surroundings") ? "Filled automatically from mapped buildings, coast and vegetation. Change it in Edit site details." : undefined} />
        </div>
      </section>

      <section className="space-y-2 rounded-xl border bg-secondary/50 p-4">
        <h2 className="font-display text-lg font-bold">Risk profile</h2>
        <ul className="space-y-1.5 text-sm">
          {notes.map((n, i) => (
            <li key={i} className="flex gap-2"><Pill>{HAZARD_LABEL[n.hazard]}</Pill><span>{n.text}</span></li>
          ))}
        </ul>
        <p className="text-xs text-muted-foreground">Screening only — not a prediction.</p>
      </section>

      <Expand title="Edit site details">
        <div className="grid gap-4 sm:grid-cols-2">
          <Select label={eff.auto.includes("surroundings") ? `Surroundings (auto: ${eff.inputs.surroundings})` : "Surroundings"} value={s.site.surroundings} onChange={(v) => upd({ surroundings: v })} options={[{ v: "unknown", l: "Auto / unknown" }, { v: "urban", l: "Urban" }, { v: "suburban", l: "Suburban" }, { v: "rural", l: "Rural" }, { v: "coastal", l: "Coastal" }, { v: "bushland", l: "Bushland edge" }]} />
          <Select label="Ground relative to street" value={s.site.groundVsStreet} onChange={(v) => upd({ groundVsStreet: v })} options={[{ v: "unknown", l: "Unknown" }, { v: "lower", l: "Lower" }, { v: "level", l: "About level" }, { v: "raised", l: "Raised" }]} />
          <Select label="Drainage after rain" value={s.site.drainage} onChange={(v) => upd({ drainage: v })} options={[{ v: "unknown", l: "Unknown" }, { v: "pools", l: "Water pools" }, { v: "some", l: "Some ponding" }, { v: "free", l: "Drains freely" }]} />
          <Select label="Observed soil texture" value={s.site.soilTexture} onChange={(v) => upd({ soilTexture: v })} options={[{ v: "unknown", l: "Unknown — use estimate" }, { v: "sandy", l: "Sandy" }, { v: "loamy", l: "Mixed / loamy" }, { v: "clay", l: "Clay-rich" }]} />
          <Select label="Soil before the event" value={s.site.soilCondition} onChange={(v) => upd({ soilCondition: v })} options={[{ v: "normal", l: "Normal" }, { v: "saturated", l: "Saturated" }]} />
          <Select label={eff.auto.includes("windExposure") ? `Wind exposure (auto: ${eff.inputs.windExposure})` : "Wind exposure"} value={s.site.windExposure} onChange={(v) => upd({ windExposure: v })} options={[{ v: "unknown", l: "Auto / unknown" }, { v: "sheltered", l: "Sheltered" }, { v: "open", l: "Open terrain" }, { v: "hilltop", l: "Hilltop / ridge" }]} />
          <RangeField label="Hard surfaces on lot" value={eff.hardSurfacePct.value ?? 45} min={0} max={100} step={5} unit="%" onChange={(v) => upd({ hardSurfacePct: v })} tag={eff.hardSurfacePct.origin === "assumed" ? <Pill tone="caution">Assumption</Pill> : <Pill tone="user">Your input</Pill>} />
          <RangeField label="Summer shade over home" value={eff.shadePct.value ?? 20} min={0} max={100} step={5} unit="%" onChange={(v) => upd({ shadePct: v })} tag={eff.shadePct.origin === "assumed" ? <Pill tone="caution">Assumption</Pill> : <Pill tone="user">Your input</Pill>} />
        </div>
        <h3 className="mt-5 mb-2 text-sm font-semibold">Known measurements (optional)</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <NumberField label="Elevation" unit="m above sea level" value={s.site.elevationM} min={-450} max={9000} step={1} onChange={(v) => upd({ elevationM: v })} />
          <NumberField label="Slope" unit="°" value={s.site.slopeDeg} min={0} max={60} onChange={(v) => upd({ slopeDeg: v })} />
          <NumberField label="Distance to waterway" unit="m" value={s.site.waterDistM} min={0} max={50000} step={10} onChange={(v) => upd({ waterDistM: v })} />
          <NumberField label="Distance to coast" unit="m" value={s.site.coastDistM} min={0} max={500000} step={10} onChange={(v) => upd({ coastDistM: v })} />
          <NumberField label="Distance to vegetation" unit="m" value={s.site.vegDistM} min={0} max={50000} step={10} onChange={(v) => upd({ vegDistM: v })} />
        </div>
        <Button variant="ghost" size="sm" className="mt-3" onClick={() => set((st) => ({ site: { ...st.site, elevationM: null, slopeDeg: null, waterDistM: null, coastDistM: null, vegDistM: null, hardSurfacePct: null, shadePct: null } }))}>Clear my measurements</Button>
      </Expand>
    </div>
  );
}
