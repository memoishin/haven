import { Check } from "lucide-react";
import { useHaven } from "@/lib/haven/state";
import type { House, Photo } from "@/lib/haven/types";
import { Expand, Pill, RangeField, Segmented, Select } from "./ui";
import { SimView } from "./SimView";
import { cn } from "@/lib/utils";

export function PhotoCredit({ photo }: { photo: Photo | null }) {
  if (!photo) return null;
  return (
    <p className="text-[11px] text-muted-foreground">
      <a href={photo.pageUrl} target="_blank" rel="noreferrer" className="underline">{photo.title}</a>
      {photo.artist && <> · {photo.artist}</>}
      {photo.licence && <> · {photo.licenceUrl ? <a className="underline" href={photo.licenceUrl} target="_blank" rel="noreferrer">{photo.licence}</a> : photo.licence}</>}
      {photo.date && <> · {photo.date}</>} · Wikimedia Commons
    </p>
  );
}

export function HouseStep({ photos, photosLoading, compact = false }: { photos: { examples: Photo[]; nearby: Photo[] }; photosLoading: boolean; compact?: boolean }) {
  const { s, set } = useHaven();
  const h = s.house;
  const upd = (p: Partial<House>) =>
    set((st) => {
      const keys = Object.keys(p);
      return { house: { ...st.house, ...p }, houseEdited: [...new Set([...st.houseEdited, ...keys])], houseAuto: st.houseAuto.filter((k) => !keys.includes(k)) };
    });
  const AUTO_LABEL: Record<string, string> = { type: "house type", roof: "roof form", walls: "walls" };
  const choose = (p: Photo) => set(() => ({ photo: p }));

  return (
    <div className="space-y-6">
      <div>
        {compact ? <h2 className="font-display text-3xl">House profile</h2> : <h1 className="font-display text-4xl">The house</h1>}
        {!compact && <p className="text-sm text-muted-foreground">Your inputs — Haven doesn’t guess condition from photos.</p>}
      </div>

      {s.houseAuto.length > 0 && (
        <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground"><Pill tone="evidence">Auto</Pill>From the mapped building: {s.houseAuto.map((k) => AUTO_LABEL[k] ?? k).join(", ")}. Change anything that’s wrong.</p>
      )}
      <Segmented label="Mode" value={h.mode} onChange={(v) => upd({ mode: v })} options={[{ v: "build", l: "Building / upgrading" }, { v: "rent", l: "Renting" }]} />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-4">
          <Select label="House type" value={h.type} onChange={(v) => upd({ type: v })} options={[{ v: "detached", l: "Detached" }, { v: "attached", l: "Attached / townhouse" }, { v: "apartment", l: "Apartment" }, { v: "raised", l: "Raised / stilt house" }]} />
          <RangeField label="Habitable floor above local ground" value={h.floorHeightM} min={0} max={h.type === "apartment" ? 30 : 4} step={0.05} unit="m" format={(v) => `${v.toFixed(2)} m`} onChange={(v) => upd({ floorHeightM: v })} />
          <Expand title="More house details">
            <div className="grid gap-4 sm:grid-cols-2">
            <Select label="External walls" value={h.walls} onChange={(v) => upd({ walls: v })} options={[{ v: "masonry", l: "Masonry" }, { v: "timber", l: "Timber" }, { v: "lightweight", l: "Lightweight" }, { v: "mixed", l: "Mixed" }]} />
              <Select label="Roof form" value={h.roof} onChange={(v) => upd({ roof: v })} options={[{ v: "gable", l: "Gable" }, { v: "hip", l: "Hip" }, { v: "flat", l: "Flat" }, { v: "skillion", l: "Skillion" }]} />
              <Select label="Roof colour" value={h.roofColour} onChange={(v) => upd({ roofColour: v })} options={[{ v: "dark", l: "Dark" }, { v: "medium", l: "Medium" }, { v: "light", l: "Light" }]} />
              <Select label="Insulation" value={String(h.insulation) as "0" | "1" | "2" | "3"} onChange={(v) => upd({ insulation: Number(v) as House["insulation"] })} options={[{ v: "0", l: "None" }, { v: "1", l: "Basic" }, { v: "2", l: "Good" }, { v: "3", l: "High" }]} />
              <Select label="Glazing" value={h.glazing} onChange={(v) => upd({ glazing: v })} options={[{ v: "single", l: "Single" }, { v: "double", l: "Double" }, { v: "performance", l: "High-performance" }]} />
              <Select label="Main windows face" value={h.orientation} onChange={(v) => upd({ orientation: v })} options={[{ v: "N", l: "North" }, { v: "E", l: "East" }, { v: "S", l: "South" }, { v: "W", l: "West" }]} />
              <RangeField label="Services height (power, hot water)" value={h.servicesHeightM} min={0} max={2.5} step={0.1} unit="m" format={(v) => `${v.toFixed(1)} m`} onChange={(v) => upd({ servicesHeightM: v })} />
            </div>
          </Expand>
        </div>

        <div className="space-y-3">
          <SimView photo={s.photo} calib={s.calib} hazard="flood" floodKind="river" current={0} level={0} stress={0} floorM={h.floorHeightM} addedM={0} badge="Your house" showCalib />
          <PhotoCredit photo={s.photo} />
          <Expand title="Choose photo" defaultOpen={!s.photo}>
            {photosLoading && <p className="text-muted-foreground">Looking for openly licensed photos…</p>}
            {!photosLoading && (
              <div className="space-y-3">
                <div>
                  <div className="mb-1 flex items-center gap-2 text-xs font-medium">Nearby photos <Pill tone="caution">May not show this address</Pill></div>
                  {photos.nearby.length === 0 ? (
                    <p className="text-xs text-muted-foreground">No openly licensed photos found within 600 m.</p>
                  ) : (
                    <Thumbs list={photos.nearby} current={s.photo} onPick={choose} />
                  )}
                </div>
                <div>
                  <div className="mb-1 text-xs font-medium">Example houses (not this address)</div>
                  <Thumbs list={photos.examples} current={s.photo} onPick={choose} />
                </div>
                {s.photo?.kind === "nearby" && (
                  <label className="flex items-center gap-2 text-xs">
                    <input type="checkbox" className="size-4 accent-primary" checked={!!s.photo.confirmedByUser} onChange={(e) => set((st) => ({ photo: st.photo && { ...st.photo, confirmedByUser: e.target.checked } }))} />
                    I’ve checked: this photo shows my property
                  </label>
                )}
              </div>
            )}
          </Expand>
          <Expand title="Photo calibration">
            <p className="mb-3 text-xs text-muted-foreground">Line up ground and eaves on the photo. These set the illustration’s scale for water depth.</p>
            <div className="space-y-3">
              <RangeField label="Ground line" value={s.calib.groundPct} min={50} max={99} step={1} unit="%" format={(v) => `${v}% down`} onChange={(v) => set((st) => ({ calib: { ...st.calib, groundPct: Math.max(v, st.calib.eavesPct + 5) } }))} />
              <RangeField label="Eaves line" value={s.calib.eavesPct} min={5} max={80} step={1} unit="%" format={(v) => `${v}% down`} onChange={(v) => set((st) => ({ calib: { ...st.calib, eavesPct: Math.min(v, st.calib.groundPct - 5) } }))} />
              <RangeField label="Assumed ground-to-eaves height" value={s.calib.groundToEavesM} min={1.5} max={10} step={0.1} unit="m" format={(v) => `${v.toFixed(1)} m`} onChange={(v) => set((st) => ({ calib: { ...st.calib, groundToEavesM: v } }))} />
            </div>
          </Expand>
        </div>
      </div>
    </div>
  );
}

function Thumbs({ list, current, onPick }: { list: Photo[]; current: Photo | null; onPick: (p: Photo) => void }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {list.map((p) => {
        const sel = current?.url === p.url;
        return (
          <button key={p.url} onClick={() => onPick(p)} aria-pressed={sel} aria-label={`Use photo ${p.title}`} className={cn("relative aspect-[4/3] overflow-hidden rounded-lg border-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", sel ? "border-primary" : "border-transparent")}>
            <img src={p.url} alt="" loading="lazy" className="h-full w-full object-cover" onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} />
            {p.distanceM != null && <span className="absolute bottom-0.5 left-0.5 rounded bg-foreground/70 px-1 text-[10px] text-primary-foreground">{Math.round(p.distanceM)} m</span>}
            {sel && <Check className="absolute right-1 top-1 size-4 rounded-full bg-primary p-0.5 text-primary-foreground" />}
          </button>
        );
      })}
    </div>
  );
}
