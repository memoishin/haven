import { createFileRoute } from "@tanstack/react-router";
import { HavenApp } from "@/components/haven/HavenApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Haven — Climate hazards for your home" },
      { name: "description", content: "Check climate hazards around any address worldwide, explore how a house could be affected, and compare resilience upgrades." },
      { property: "og:title", content: "Haven — Climate hazards for your home" },
      { property: "og:description", content: "Check climate hazards around any address and compare practical resilience upgrades." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HavenApp,
});
