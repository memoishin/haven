import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { getShare } from "@/lib/haven/reports.functions";
import { buildReport, downloadPdf } from "@/lib/haven/report";
import type { Snapshot } from "@/lib/haven/state";

export const Route = createFileRoute("/r/$slug")({
  loader: async ({ params }) => {
    const { json } = await getShare({ data: { slug: params.slug } });
    return { snapshot: json ? (JSON.parse(json) as Snapshot) : null };
  },
  head: ({ loaderData }) => {
    const where = loaderData?.snapshot?.place.locality ?? loaderData?.snapshot?.place.country ?? "a property";
    const title = `Haven report — ${where}`;
    const desc = `Climate hazard evidence, house details and upgrade comparison for ${where}.`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary" },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  errorComponent: () => <Msg text="This report could not be loaded." />,
  notFoundComponent: () => <Msg text="Report not found." />,
  component: ReportPage,
});

function Msg({ text }: { text: string }) {
  return (
    <div className="mx-auto max-w-2xl space-y-4 px-4 py-16">
      <p>{text}</p>
      <Link to="/" className="text-primary underline">Open Haven</Link>
    </div>
  );
}

function ReportPage() {
  const { snapshot } = Route.useLoaderData();
  const nav = useNavigate();
  if (!snapshot) return <Msg text="Report not found." />;
  const open = () => {
    sessionStorage.setItem("haven:open", JSON.stringify(snapshot));
    void nav({ to: "/" });
  };
  return (
    <div className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <header className="flex flex-wrap items-center gap-3">
        <Link to="/" className="font-display text-3xl font-bold">Haven<span className="text-primary">.</span></Link>
        <span className="rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">Shared report · Illustrative scenario</span>
      </header>
      <div className="flex flex-wrap gap-2">
        <Button className="h-11" onClick={open}>Open in Haven</Button>
        <Button variant="outline" className="h-11" onClick={() => downloadPdf(snapshot)}>Download PDF</Button>
      </div>
      {buildReport(snapshot).map((s) => (
        <section key={s.title} className="rounded-xl border bg-card p-4">
          <h2 className="font-display text-lg font-bold">{s.title}</h2>
          <ul className="mt-2 space-y-1 text-sm">
            {s.lines.map((l, i) => <li key={i}>{l}</li>)}
          </ul>
        </section>
      ))}
    </div>
  );
}
