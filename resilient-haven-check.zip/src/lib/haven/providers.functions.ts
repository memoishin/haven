import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { BuildingValue, ClimateValue, Evidence, FutureValue, Photo, Place, Precision, RiverValue, SiteEvidence, SoilValue } from "./types";

/* Provider layer: each provider is bounded (timeout), cached, and fails independently. */

const UA = "Haven/0.1 (COP31 hackathon prototype; team changemakers)";
const cache = new Map<string, { t: number; v: unknown }>();

async function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < ttlMs) return hit.v as T;
  const v = await fn();
  if (cache.size > 500) cache.clear();
  cache.set(key, { t: Date.now(), v });
  return v;
}

async function fetchJson(url: string, init: RequestInit = {}, timeoutMs = 10000, retries = 1): Promise<any> {
  try {
    return await fetchOnce(url, init, timeoutMs);
  } catch (e) {
    if (retries <= 0) throw e;
    await new Promise((r) => setTimeout(r, 600));
    return fetchJson(url, init, timeoutMs, retries - 1);
  }
}

async function fetchOnce(url: string, init: RequestInit, timeoutMs: number): Promise<any> {
  const c = new AbortController();
  const id = setTimeout(() => c.abort(), timeoutMs);
  try {
    const r = await fetch(url, { ...init, signal: c.signal, headers: { "User-Agent": UA, Accept: "application/json", ...(init.headers ?? {}) } });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally {
    clearTimeout(id);
  }
}

// Nominatim usage policy: max 1 request/second, identify the app, cache results.
let nextNominatim = 0;
async function nominatim(url: string) {
  const now = Date.now();
  const wait = Math.max(0, nextNominatim - now);
  nextNominatim = now + wait + 1100;
  if (wait) await new Promise((r) => setTimeout(r, wait));
  return fetchJson(url, {}, 9000);
}

const NOM = "OpenStreetMap Nominatim (© OpenStreetMap contributors, ODbL)";

function placeFrom(r: any, precision?: Precision): Place {
  const a = r.address ?? {};
  let p: Precision = precision ?? "locality";
  if (!precision) {
    const at = r.addresstype ?? r.type;
    if (a.house_number || ["building", "house", "amenity", "shop", "office"].includes(at) || r.category === "building") p = "address";
    else if (["road", "street", "residential"].includes(at)) p = "street";
  }
  return {
    lat: Number(r.lat),
    lon: Number(r.lon),
    label: r.display_name,
    locality: a.city ?? a.town ?? a.village ?? a.hamlet ?? a.suburb ?? a.municipality,
    region: a.state ?? a.region ?? a.county ?? a.province,
    country: a.country,
    countryCode: a.country_code?.toUpperCase(),
    precision: p,
    source: NOM,
  };
}

export const geocode = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ q: z.string().trim().min(2).max(200) }).parse(d))
  .handler(async ({ data }) => {
    try {
      const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=6&q=${encodeURIComponent(data.q)}`;
      const res = await cached(`geo:${data.q.toLowerCase()}`, 86400000, () => nominatim(url));
      return { results: (res as any[]).map((r) => placeFrom(r)), error: null as string | null };
    } catch (e) {
      console.error("geocode failed", e);
      return { results: [] as Place[], error: "Address search is unavailable right now. Pick a point on the map or enter coordinates." };
    }
  });

const coord = z.object({ lat: z.number().min(-90).max(90), lon: z.number().min(-180).max(180) });

export const reverseGeocode = createServerFn({ method: "POST" })
  .inputValidator((d) => coord.parse(d))
  .handler(async ({ data }) => {
    const base: Place = { lat: data.lat, lon: data.lon, label: `${data.lat.toFixed(5)}, ${data.lon.toFixed(5)}`, precision: "manual", source: "Manually selected point" };
    try {
      const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=12&lat=${data.lat}&lon=${data.lon}`;
      const r = await cached(`rev:${data.lat.toFixed(4)},${data.lon.toFixed(4)}`, 86400000, () => nominatim(url));
      if ((r as any)?.error) return base;
      const p = placeFrom(r, "manual");
      return { ...p, lat: data.lat, lon: data.lon, label: `Point near ${p.locality ?? p.region ?? p.country ?? "selected area"}`, source: `Manually selected point; area names from ${NOM}` };
    } catch {
      return base;
    }
  });

// ---------- geometry ----------
const R = 6371000;
function toXY(lat: number, lon: number, lat0: number, lon0: number) {
  const x = ((lon - lon0) * Math.PI) / 180 * R * Math.cos((lat0 * Math.PI) / 180);
  const y = ((lat - lat0) * Math.PI) / 180 * R;
  return [x, y] as const;
}
function distToPolyline(pts: { lat: number; lon: number }[], lat0: number, lon0: number): number {
  let best = Infinity;
  for (let i = 0; i < pts.length; i++) {
    const [ax, ay] = toXY(pts[i]!.lat, pts[i]!.lon, lat0, lon0);
    if (i === 0 || pts.length === 1) best = Math.min(best, Math.hypot(ax, ay));
    if (i + 1 < pts.length) {
      const [bx, by] = toXY(pts[i + 1]!.lat, pts[i + 1]!.lon, lat0, lon0);
      const dx = bx - ax, dy = by - ay;
      const L = dx * dx + dy * dy;
      const t = L ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / L)) : 0;
      best = Math.min(best, Math.hypot(ax + t * dx, ay + t * dy));
    }
  }
  return best;
}

const today = () => new Date().toISOString();

async function elevationProvider(lat: number, lon: number): Promise<{ elevation: Evidence<number>; slope: Evidence<number>; relief: Evidence<number> }> {
  const d = 250;
  const dLat = d / 111320;
  const dLon = d / (111320 * Math.max(0.1, Math.cos((lat * Math.PI) / 180)));
  const lats = [lat, lat + dLat, lat - dLat, lat, lat];
  const lons = [lon, lon, lon, lon + dLon, lon - dLon];
  const meta = { source: "Open-Meteo Elevation API (Copernicus DEM GLO-90)", sourceUrl: "https://open-meteo.com/en/docs/elevation-api", licence: "CC BY 4.0 (Open-Meteo); Copernicus DEM © DLR/ESA", retrieved: today(), lat, lon };
  try {
    const r = await cached(`elev:${lat.toFixed(4)},${lon.toFixed(4)}`, 86400000, () =>
      fetchJson(`https://api.open-meteo.com/v1/elevation?latitude=${lats.map((v) => v.toFixed(6)).join(",")}&longitude=${lons.map((v) => v.toFixed(6)).join(",")}`, {}, 8000),
    );
    const e = r.elevation as number[];
    if (!Array.isArray(e) || e.length < 5 || e.some((v) => !Number.isFinite(v))) throw new Error("bad elevation");
    const dzdy = (e[1]! - e[2]!) / (2 * d);
    const dzdx = (e[3]! - e[4]!) / (2 * d);
    const slopeDeg = (Math.atan(Math.hypot(dzdx, dzdy)) * 180) / Math.PI;
    return {
      elevation: { ...meta, status: "estimate", value: Math.round(e[0]!), unit: "m above mean sea level (EGM2008 geoid)", resolution: "~90 m grid", limitations: "Satellite terrain model; buildings and trees can bias values by several metres. Not a surveyed floor or ground level." },
      relief: { ...meta, status: "estimate", value: Math.round(e[0]! - (e[1]! + e[2]! + e[3]! + e[4]!) / 4), unit: "m relative to points 250 m away", resolution: "~90 m grid", limitations: "Positive means the point sits higher than its surroundings (ridge or hill). Used only to suggest wind exposure." },
      slope: { ...meta, status: "estimate", value: Math.round(slopeDeg * 10) / 10, unit: "° (coarse, over ±250 m)", resolution: "Derived from 5 points spaced 250 m", limitations: "Coarse terrain gradient around the point, not the slope of your lot." },
    };
  } catch (err) {
    console.error("elevation", err);
    const fail = { ...meta, status: "unavailable" as const, limitations: "Elevation service did not respond.", note: "Enter a known value if you have one." };
    return { elevation: fail, slope: { ...fail }, relief: { ...fail } };
  }
}

async function soilProvider(lat: number, lon: number): Promise<Evidence<SoilValue>> {
  const first = await soilAt(lat, lon);
  if (first.status === "estimate") return first;
  // Urban cores and water often have no modelled value: try points ~500 m away.
  const d = 0.0045;
  const tries = await Promise.all([[d, 0], [-d, 0], [0, d], [0, -d]].map(([a, b]) => soilAt(lat + a!, lon + b! / Math.max(0.2, Math.cos((lat * Math.PI) / 180)))));
  const hit = tries.find((t) => t.status === "estimate");
  if (hit) return { ...hit, lat, lon, note: "No value at the exact point; nearest modelled value about 500 m away.", limitations: `${hit.limitations} Taken about 500 m from the point.` };
  return first;
}

async function soilAt(lat: number, lon: number): Promise<Evidence<SoilValue>> {
  const meta = { source: "ISRIC SoilGrids 2.0 (topsoil 0–5 cm, mean)", sourceUrl: "https://www.isric.org/explore/soilgrids", licence: "CC BY 4.0", retrieved: today(), resolution: "250 m grid", lat, lon };
  try {
    const r = await cached(`soil:${lat.toFixed(3)},${lon.toFixed(3)}`, 86400000, () =>
      fetchJson(`https://rest.isric.org/soilgrids/v2.0/properties/query?lon=${lon}&lat=${lat}&property=clay&property=sand&property=silt&depth=0-5cm&value=mean`, {}, 12000),
    );
    const get = (n: string) => {
      const l = r.properties.layers.find((x: any) => x.name === n);
      const v = l?.depths?.[0]?.values?.mean;
      const f = l?.unit_measure?.d_factor ?? 10;
      return v == null ? null : v / f; // g/kg ÷ 10 → %
    };
    const clay = get("clay"), sand = get("sand"), silt = get("silt");
    if (clay == null || sand == null || silt == null) return { ...meta, status: "unavailable", limitations: "No modelled soil value here (water, urban core or outside model coverage).", note: "Choose an observed soil texture instead." };
    const texture = clay >= 35 ? "clay" : sand >= 65 ? "sandy" : "loamy";
    return { ...meta, status: "estimate", value: { clayPct: Math.round(clay), sandPct: Math.round(sand), siltPct: Math.round(silt), texture }, unit: "% by mass", limitations: "Machine-learning prediction from soil samples and covariates. Fill, compaction and local variation are common on building sites." };
  } catch (err) {
    console.error("soil", err);
    return { ...meta, status: "unavailable", limitations: "Soil service did not respond in time.", note: "Choose an observed soil texture instead." };
  }
}

async function osmProvider(lat: number, lon: number) {
  const meta = { source: "OpenStreetMap via Overpass API", sourceUrl: "https://www.openstreetmap.org/copyright", licence: "ODbL © OpenStreetMap contributors", retrieved: today(), resolution: "Mapped features (varies by community mapping)", lat, lon };
  const q = `[out:json][timeout:20];(
way["waterway"~"^(river|stream|canal|creek|brook)$"](around:3000,${lat},${lon});
way["natural"="water"](around:3000,${lat},${lon});
relation["natural"="water"](around:3000,${lat},${lon});
way["natural"="coastline"](around:10000,${lat},${lon});
way["natural"~"^(wood|scrub|heath)$"](around:2000,${lat},${lon});
way["landuse"="forest"](around:2000,${lat},${lon});
relation["natural"="wood"](around:2000,${lat},${lon});
relation["landuse"="forest"](around:2000,${lat},${lon});
);out geom qt 400;`;
  let data: any = null;
  for (const ep of ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"]) {
    try {
      data = await cached(`osm:${lat.toFixed(4)},${lon.toFixed(4)}`, 86400000, () =>
        fetchJson(ep, { method: "POST", body: `data=${encodeURIComponent(q)}`, headers: { "Content-Type": "application/x-www-form-urlencoded" } }, 18000),
      );
      break;
    } catch (err) {
      console.error("overpass", ep, err);
    }
  }
  const unavailable = { ...meta, status: "unavailable" as const, limitations: "Map feature service did not respond.", note: "Enter a known distance if you have one." };
  if (!data) return { waterway: unavailable, coast: unavailable, vegetation: unavailable } as Pick<SiteEvidence, "waterway" | "coast" | "vegetation">;

  let water: { d: number; name?: string; kind: string } | null = null;
  let coast: number | null = null;
  let veg: { d: number; kind: string } | null = null;
  for (const el of data.elements ?? []) {
    const lines: { lat: number; lon: number }[][] = el.geometry ? [el.geometry] : (el.members ?? []).filter((m: any) => m.geometry).map((m: any) => m.geometry);
    if (!lines.length) continue;
    const d = Math.min(...lines.map((l) => distToPolyline(l, lat, lon)));
    const t = el.tags ?? {};
    if (t.natural === "coastline") coast = coast == null ? d : Math.min(coast, d);
    else if (t.waterway || t.natural === "water") {
      if (!water || d < water.d) water = { d, name: t.name, kind: t.waterway ?? t.water ?? "water body" };
    } else if (!veg || d < veg.d) veg = { d, kind: t.natural ?? t.landuse ?? "vegetation" };
  }
  const lim = "Distance to the nearest mapped feature edge. Mapping completeness varies; small creeks, drains and vegetation may be missing.";
  return {
    waterway: water
      ? { ...meta, status: "estimate", value: { distanceM: Math.round(water.d), name: water.name, kind: water.kind }, unit: "m", limitations: `${lim} Proximity is not a flood probability.` }
      : { ...meta, status: "none-found", searchRadiusM: 3000, limitations: lim, note: "No waterway mapped within 3 km." },
    coast: coast != null
      ? { ...meta, status: "estimate", value: { distanceM: Math.round(coast) }, unit: "m", limitations: lim }
      : { ...meta, status: "none-found", searchRadiusM: 10000, limitations: lim, note: "No coastline mapped within 10 km." },
    vegetation: veg
      ? { ...meta, status: "estimate", value: { distanceM: Math.round(veg.d), kind: veg.kind }, unit: "m", limitations: `${lim} 0 m means the point is inside a mapped area.` }
      : { ...meta, status: "none-found", searchRadiusM: 2000, limitations: lim, note: "No woodland, forest or scrub mapped within 2 km." },
  } as Pick<SiteEvidence, "waterway" | "coast" | "vegetation">;
}

// ---------- Climate records (ERA5 via Open-Meteo archive) ----------
const pct = (arr: number[], q: number) => {
  const a = [...arr].sort((x, y) => x - y);
  return a[Math.min(a.length - 1, Math.max(0, Math.floor(q * (a.length - 1))))]!;
};
const nums = (a: unknown): number[] => (Array.isArray(a) ? a.filter((v): v is number => typeof v === "number" && Number.isFinite(v)) : []);
const r1 = (v: number) => Math.round(v * 10) / 10;

async function climateProvider(lat: number, lon: number): Promise<Evidence<ClimateValue>> {
  const meta = { source: "ERA5 reanalysis via Open-Meteo Historical Weather API", sourceUrl: "https://open-meteo.com/en/docs/historical-weather-api", licence: "CC BY 4.0 (Open-Meteo); ERA5 © ECMWF / Copernicus", retrieved: today(), resolution: "~25 km grid, daily values", lat, lon };
  try {
    const r = await cached(`clim:${lat.toFixed(2)},${lon.toFixed(2)}`, 7 * 86400000, () =>
      fetchJson(`https://archive-api.open-meteo.com/v1/archive?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&start_date=1995-01-01&end_date=2024-12-31&daily=temperature_2m_max,wind_gusts_10m_max&timezone=GMT`, {}, 25000),
    );
    const t = nums(r.daily?.temperature_2m_max);
    const g = nums(r.daily?.wind_gusts_10m_max);
    if (t.length < 3000 || g.length < 3000) throw new Error("short series");
    return {
      ...meta,
      status: "estimate",
      value: { period: "1995–2024", tmaxRecord: r1(Math.max(...t)), tmaxP95: r1(pct(t, 0.95)), tmaxP99: r1(pct(t, 0.99)), hotDays35PerYr: r1(t.filter((v) => v >= 35).length / 30), gustRecord: Math.round(Math.max(...g)), gustP95: Math.round(pct(g, 0.95)), gustP99: Math.round(pct(g, 0.99)) },
      unit: "°C daily maximum air temperature; km/h daily maximum gust at 10 m",
      limitations: "Grid-cell averages smooth out local extremes. Gusts from reanalysis underestimate the strongest tropical-cyclone and thunderstorm gusts. Past records are not a forecast.",
    };
  } catch (err) {
    console.error("climate", err);
    return { ...meta, status: "unavailable", limitations: "Climate record service did not respond.", note: "Event presets use generic values instead." };
  }
}

async function futureProvider(lat: number, lon: number): Promise<Evidence<FutureValue>> {
  const model = "EC_Earth3P_HR";
  const meta = { source: `CMIP6 HighResMIP (${model}) via Open-Meteo Climate API`, sourceUrl: "https://open-meteo.com/en/docs/climate-api", licence: "CC BY 4.0 (Open-Meteo); CMIP6 data CC BY 4.0", retrieved: today(), resolution: "~30 km grid, downscaled daily", lat, lon };
  try {
    const r = await cached(`fut:${lat.toFixed(2)},${lon.toFixed(2)}`, 30 * 86400000, () =>
      fetchJson(`https://climate-api.open-meteo.com/v1/climate?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&start_date=1995-01-01&end_date=2050-12-31&models=${model}&daily=temperature_2m_max`, {}, 25000),
    );
    const times: string[] = r.daily?.time ?? [];
    const vals: unknown[] = r.daily?.temperature_2m_max ?? [];
    const base: number[] = [], fut: number[] = [];
    times.forEach((d, i) => {
      const v = vals[i];
      if (typeof v !== "number") return;
      const y = Number(d.slice(0, 4));
      if (y >= 1995 && y <= 2014) base.push(v);
      else if (y >= 2031 && y <= 2050) fut.push(v);
    });
    if (base.length < 3000 || fut.length < 3000) throw new Error("short series");
    return {
      ...meta,
      status: "estimate",
      value: { model, basePeriod: "1995–2014", futurePeriod: "2031–2050", hotDays35Base: r1(base.filter((v) => v >= 35).length / 20), hotDays35Future: r1(fut.filter((v) => v >= 35).length / 20), tmaxRecordFuture: r1(Math.max(...fut)) },
      unit: "days per year at or above 35 °C (model)",
      limitations: "One climate model under a high-emissions pathway (SSP5-8.5 forcing in HighResMIP). Compare the model's future with its own past, not with observations. Other models differ.",
    };
  } catch (err) {
    console.error("future", err);
    return { ...meta, status: "unavailable", limitations: "Climate projection service did not respond." };
  }
}

// ---------- River flow (GloFAS via Open-Meteo Flood API) ----------
async function riverProvider(lat: number, lon: number): Promise<Evidence<RiverValue>> {
  const meta = { source: "GloFAS v4 river discharge via Open-Meteo Flood API", sourceUrl: "https://open-meteo.com/en/docs/flood-api", licence: "CC BY 4.0 (Open-Meteo); GloFAS © Copernicus Emergency Management Service", retrieved: today(), resolution: "~5 km river grid, daily", lat, lon };
  try {
    const r = await cached(`river:${lat.toFixed(2)},${lon.toFixed(2)}`, 7 * 86400000, () =>
      fetchJson(`https://flood-api.open-meteo.com/v1/flood?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&daily=river_discharge&start_date=1984-01-01&end_date=2024-12-31`, {}, 20000),
    );
    const times: string[] = r.daily?.time ?? [];
    const raw: unknown[] = r.daily?.river_discharge ?? [];
    const q = nums(raw);
    if (q.length < 3000) throw new Error("short series");
    const max = Math.max(...q);
    if (max < 1) return { ...meta, status: "none-found", limitations: "No significant modelled river in the nearest grid cell.", note: "No large river modelled here. Small creeks and drains are not included." };
    const idx = raw.findIndex((v) => v === max);
    return {
      ...meta,
      status: "estimate",
      value: { period: "1984–2024", maxM3s: Math.round(max), p99M3s: Math.round(pct(q, 0.99)), medianM3s: r1(pct(q, 0.5)), maxDate: times[idx] ?? "" },
      unit: "m³/s river discharge",
      limitations: "Flow in the nearest modelled river cell, which may not be the river closest to you. Flow is not water depth at the house and not a flood probability.",
    };
  } catch (err) {
    console.error("river", err);
    return { ...meta, status: "unavailable", limitations: "River flow service did not respond." };
  }
}

// ---------- Buildings & land use (OSM) ----------
async function buildingsProvider(lat: number, lon: number): Promise<Evidence<BuildingValue>> {
  const meta = { source: "OpenStreetMap buildings and land use via Overpass API", sourceUrl: "https://www.openstreetmap.org/copyright", licence: "ODbL © OpenStreetMap contributors", retrieved: today(), resolution: "Mapped features", lat, lon };
  const q = `[out:json][timeout:15];(way["building"](around:300,${lat},${lon}););out tags center qt 1500;way["landuse"](around:150,${lat},${lon});out tags center qt 20;`;
  for (const ep of ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"]) {
    try {
      const data = await cached(`bld:${lat.toFixed(4)},${lon.toFixed(4)}`, 86400000, () =>
        fetchJson(ep, { method: "POST", body: `data=${encodeURIComponent(q)}`, headers: { "Content-Type": "application/x-www-form-urlencoded" } }, 16000, 0),
      );
      let count = 0;
      let landuse: string | null = null;
      let nearest: BuildingValue["nearest"] = null;
      if (data.remark && !(data.elements ?? []).length) throw new Error(String(data.remark));
      let bestLu = Infinity;
      for (const el of data.elements ?? []) {
        const t = el.tags ?? {};
        if (t.landuse && !t.building && el.center) {
          const d = distToPolyline([{ lat: el.center.lat, lon: el.center.lon }], lat, lon);
          if (d < bestLu) { bestLu = d; landuse = t.landuse; }
          continue;
        }
        if (t.building && el.center) {
          count++;
          const d = distToPolyline([{ lat: el.center.lat, lon: el.center.lon }], lat, lon);
          if (d <= 40 && (!nearest || d < nearest.distanceM)) {
            const lv = Number(t["building:levels"]);
            nearest = { distanceM: Math.round(d), building: t.building, ...(Number.isFinite(lv) && lv > 0 ? { levels: lv } : {}), ...(t["roof:shape"] ? { roofShape: t["roof:shape"] } : {}), ...(t["building:material"] ? { material: t["building:material"] } : {}) };
          }
        }
      }
      return { ...meta, status: "estimate", value: { count300m: count, landuse, nearest }, unit: "buildings within 300 m", limitations: "Building mapping is incomplete in many places. Tags like roof shape or material are often missing; a mapped building near the point may not be your house." };
    } catch (err) {
      console.error("buildings", ep, err);
    }
  }
  return { ...meta, status: "unavailable", limitations: "Map building service did not respond." };
}

// ---------- Country price level (World Bank) ----------
async function priceLevelProvider(cc: string | undefined, lat: number, lon: number): Promise<Evidence<number>> {
  const meta = { source: "World Bank — PPP conversion factor ÷ official exchange rate (PA.NUS.PPP / PA.NUS.FCRF)", sourceUrl: "https://data.worldbank.org/indicator/PA.NUS.PPP", licence: "CC BY 4.0", retrieved: today(), resolution: "National", lat, lon };
  if (!cc || !/^[A-Z]{2}$/.test(cc)) return { ...meta, status: "unavailable", limitations: "Country not known.", note: "Costs shown at US price level." };
  try {
    const wb = (ind: string) => cached(`wb:${ind}:${cc}`, 30 * 86400000, () => fetchJson(`https://api.worldbank.org/v2/country/${cc}/indicator/${ind}?format=json&mrnev=1`, {}, 10000));
    const [ppp, fx] = await Promise.all([wb("PA.NUS.PPP"), wb("PA.NUS.FCRF")]);
    const a = ppp?.[1]?.[0]?.value, b = fx?.[1]?.[0]?.value;
    const year = ppp?.[1]?.[0]?.date;
    if (typeof a !== "number" || typeof b !== "number" || b <= 0) throw new Error("no value");
    const v = a / b;
    return { ...meta, status: "estimate", value: Math.round(v * 100) / 100, unit: `ratio to USA = 1 (${year})`, limitations: "Economy-wide price level, not construction prices. Local labour and material costs vary widely." };
  } catch (err) {
    console.error("ppp", err);
    return { ...meta, status: "unavailable", limitations: "World Bank data did not respond.", note: "Costs shown at US price level." };
  }
}

export const getSiteEvidence = createServerFn({ method: "POST" })
  .inputValidator((d) => coord.extend({ countryCode: z.string().max(3).optional() }).parse(d))
  .handler(async ({ data }): Promise<SiteEvidence> => {
    const { lat, lon } = data;
    const [el, soil, osm, climate, future, river, buildings, priceLevel] = await Promise.all([
      elevationProvider(lat, lon), soilProvider(lat, lon), osmProvider(lat, lon),
      climateProvider(lat, lon), futureProvider(lat, lon), riverProvider(lat, lon), buildingsProvider(lat, lon), priceLevelProvider(data.countryCode, lat, lon),
    ]);
    return { ...el, soil, ...osm, climate, future, river, buildings, priceLevel };
  });

// ---------- Photos (Wikimedia Commons) ----------
const strip = (s?: string) => s?.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();

function photoFrom(p: any, kind: Photo["kind"], distanceM?: number): Photo | null {
  const ii = p.imageinfo?.[0];
  if (!ii?.thumburl) return null;
  const m = ii.extmetadata ?? {};
  return {
    url: ii.thumburl,
    title: p.title.replace(/^File:/, "").replace(/\.[a-z]+$/i, ""),
    pageUrl: ii.descriptionurl,
    artist: strip(m.Artist?.value),
    licence: strip(m.LicenseShortName?.value),
    licenceUrl: m.LicenseUrl?.value,
    date: strip(m.DateTimeOriginal?.value)?.slice(0, 10),
    kind,
    distanceM,
  };
}

const COMMONS = "https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&prop=imageinfo|coordinates&iiprop=url|extmetadata&iiurlwidth=1280";

export const EXAMPLE_TITLES: Record<string, string> = {
  detached: "File:Detached house, Garden Suburb, Dursley.jpg",
  attached: "File:Terrace Houses, Subiaco, May 2021 01.jpg",
  raised: "File:Queenslander house in Laidley.jpg",
};

export const getPhotos = createServerFn({ method: "POST" })
  .inputValidator((d) => coord.extend({ houseType: z.enum(["detached", "attached", "apartment", "raised"]) }).parse(d))
  .handler(async ({ data }) => {
    const examples: Photo[] = [];
    const nearby: Photo[] = [];
    try {
      const titles = Object.values(EXAMPLE_TITLES).join("|");
      const r = await cached("examples", 86400000, () => fetchJson(`${COMMONS}&titles=${encodeURIComponent(titles)}`));
      const pages = Object.values(r.query?.pages ?? {}) as any[];
      const order = [EXAMPLE_TITLES[data.houseType] ?? EXAMPLE_TITLES['detached'], ...Object.values(EXAMPLE_TITLES)];
      pages.sort((a, b) => order.indexOf(a.title) - order.indexOf(b.title));
      for (const p of pages) {
        const ph = photoFrom(p, "example");
        if (ph) examples.push(ph);
      }
    } catch (e) {
      console.error("examples", e);
    }
    try {
      const r = await cached(`near:${data.lat.toFixed(4)},${data.lon.toFixed(4)}`, 86400000, () =>
        fetchJson(`${COMMONS}&generator=geosearch&ggsnamespace=6&ggsradius=600&ggslimit=20&ggscoord=${data.lat}|${data.lon}&ggsprop=dist`),
      );
      const pages = Object.values(r.query?.pages ?? {}) as any[];
      for (const p of pages) {
        if (!/\.(jpe?g|png)$/i.test(p.title) || /map|logo|plan|diagram|svg/i.test(p.title)) continue;
        const ph = photoFrom(p, "nearby", p.coordinates?.[0]?.dist);
        if (ph) nearby.push(ph);
      }
      nearby.sort((a, b) => (a.distanceM ?? 0) - (b.distanceM ?? 0));
    } catch (e) {
      console.error("nearby", e);
    }
    return { examples, nearby: nearby.slice(0, 9) };
  });
