import type { Hazard, UpgradeId, Upgrades } from "./types";

export interface UpgradeDef {
  id: UpgradeId;
  hazard: Hazard;
  title: string;
  param: { label: string; unit: string; min: number; max: number; step: number; default: number; labels?: string[] };
  explain: string;
  renter: string;
  landlord: boolean;
  suggested: boolean;
  guidance: { label: string; url: string };
}

const FEMA = { label: "FEMA building science (USA example)", url: "https://www.fema.gov/emergency-managers/risk-management/building-science" };
const YOURHOME = { label: "YourHome passive design (Australia example)", url: "https://www.yourhome.gov.au/passive-design" };
const FIREWISE = { label: "NFPA Firewise USA (example)", url: "https://www.nfpa.org/firewise" };
const IBHS = { label: "IBHS FORTIFIED (USA example)", url: "https://fortifiedhome.org/" };

export const UPGRADES: UpgradeDef[] = [
  // Flood
  { id: "raise_floor", hazard: "flood", title: "Raise the finished floor", param: { label: "Added height", unit: "m", min: 0, max: 1.5, step: 0.05, default: 0.3 }, explain: "Lifts the habitable floor. Directly changes water above floor in the model.", renter: "Major works — not a renter option. Ask whether floor height was set above local flood levels.", landlord: true, suggested: true, guidance: FEMA },
  { id: "flood_finishes", hazard: "flood", title: "Flood-resilient finishes", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 60 }, explain: "Water-tolerant floors, linings and joinery at low levels can shorten clean-up. Does not keep water out.", renter: "Ask about floor and wall finishes; keep valuables off the floor.", landlord: true, suggested: true, guidance: FEMA },
  { id: "elevate_services", hazard: "flood", title: "Elevate essential services", param: { label: "Equipment height above ground", unit: "m", min: 0.3, max: 2.5, step: 0.1, default: 1.2 }, explain: "Moves power outlets, switchboards and hot water above the selected water level.", renter: "Ask where the switchboard and hot water unit sit relative to ground.", landlord: true, suggested: true, guidance: FEMA },
  { id: "permeable", hazard: "flood", title: "Permeable paving", param: { label: "Coverage of hard surfaces", unit: "%", min: 0, max: 100, step: 5, default: 40 }, explain: "Lets some rain soak in. Only affects the surface-water comparison — not river or coastal flooding.", renter: "Landlord approval needed. Ask how the yard drains after heavy rain.", landlord: true, suggested: false, guidance: FEMA },
  { id: "drainage", hazard: "flood", title: "Improve site drainage", param: { label: "Extent of work", unit: "%", min: 0, max: 100, step: 5, default: 50 }, explain: "Grading and drains that move rainwater away from the house. Surface-water comparison only.", renter: "Report blocked drains; keep grates clear.", landlord: true, suggested: false, guidance: FEMA },
  { id: "rain_storage", hazard: "flood", title: "Rainwater storage", param: { label: "Available empty capacity", unit: "L", min: 0, max: 20000, step: 500, default: 5000 }, explain: "Empty tank volume can hold some roof runoff in smaller storms. Surface-water comparison only.", renter: "Landlord approval needed for tanks.", landlord: true, suggested: false, guidance: FEMA },
  // Heat
  { id: "ext_shading", hazard: "heat", title: "External shading", param: { label: "Glazing coverage", unit: "%", min: 0, max: 100, step: 5, default: 60 }, explain: "Awnings, eaves or screens block sun before it reaches glass.", renter: "Removable external blinds may need approval; internal blinds help less.", landlord: true, suggested: true, guidance: YOURHOME },
  { id: "insulation", hazard: "heat", title: "Ceiling or roof insulation", param: { label: "Insulation level", unit: "level", min: 1, max: 3, step: 1, default: 3, labels: ["Basic", "Good", "High"] }, explain: "Reduces heat flowing in through the roof. Benefit only counts above what the house already has.", renter: "Ask what insulation is installed and its rating.", landlord: true, suggested: true, guidance: YOURHOME },
  { id: "cross_vent", hazard: "heat", title: "Cross-ventilation", param: { label: "Extent of improvement", unit: "%", min: 0, max: 100, step: 5, default: 50 }, explain: "Openable windows on opposite sides help purge heat when outside air is cooler.", renter: "Use fans and open opposite windows in cooler hours.", landlord: false, suggested: true, guidance: YOURHOME },
  { id: "cool_roof", hazard: "heat", title: "Lighter or reflective roof", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 100 }, explain: "Reflects more sunlight from the roof surface.", renter: "Landlord decision. Ask about roof colour.", landlord: true, suggested: false, guidance: YOURHOME },
  { id: "glazing_up", hazard: "heat", title: "Improved glazing", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 50 }, explain: "Better glass or films reduce solar heat gain. Benefit reduced if glazing is already improved.", renter: "Removable films may need approval.", landlord: true, suggested: false, guidance: YOURHOME },
  // Fire
  { id: "ember_seal", hazard: "fire", title: "Seal ember entry points", param: { label: "Treated coverage", unit: "%", min: 0, max: 100, step: 5, default: 80 }, explain: "Mesh vents, seal gaps under doors, roofs and eaves where embers can enter.", renter: "Ask about vent screens; door seals are often simple to request.", landlord: true, suggested: true, guidance: FIREWISE },
  { id: "fuel_mgmt", hazard: "fire", title: "Maintain nearby fuel", param: { label: "Extent of maintenance", unit: "%", min: 0, max: 100, step: 5, default: 70 }, explain: "Keep grass short, remove dead material and move flammable items away from walls.", renter: "Often allowed — check your lease for garden duties.", landlord: false, suggested: true, guidance: FIREWISE },
  { id: "gutters", hazard: "fire", title: "Clean and maintain gutters", param: { label: "Completion", unit: "%", min: 0, max: 100, step: 5, default: 100 }, explain: "Dry leaves in gutters can catch embers.", renter: "Ask who is responsible and when gutters were last cleaned.", landlord: false, suggested: true, guidance: FIREWISE },
  { id: "cladding", hazard: "fire", title: "More resistant cladding", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 50 }, explain: "Non-combustible lower wall cladding. Smaller benefit if walls are already masonry.", renter: "Major works — landlord decision.", landlord: true, suggested: false, guidance: FIREWISE },
  // Wind
  { id: "roof_conn", hazard: "wind", title: "Strengthen roof connections", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 100 }, explain: "Ties and straps connecting roof to walls form a continuous load path.", renter: "Ask whether the roof has been inspected or upgraded.", landlord: true, suggested: true, guidance: IBHS },
  { id: "openings", hazard: "wind", title: "Protect windows and doors", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 70 }, explain: "Shutters or impact-rated glazing keep wind and debris out.", renter: "Ask about storm shutters; know where to shelter.", landlord: true, suggested: true, guidance: IBHS },
  { id: "big_doors", hazard: "wind", title: "Reinforce large or garage doors", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 100 }, explain: "Large doors can fail first and let pressure into the building.", renter: "Ask whether the garage door is wind-rated.", landlord: true, suggested: false, guidance: IBHS },
  { id: "roof_fixings", hazard: "wind", title: "Improve roof fixings", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 100 }, explain: "Extra screws or fasteners hold roof sheets and tiles.", renter: "Report loose sheets or tiles.", landlord: true, suggested: true, guidance: IBHS },
  { id: "fixtures", hazard: "wind", title: "Secure rooftop fixtures", param: { label: "Coverage", unit: "%", min: 0, max: 100, step: 5, default: 100 }, explain: "Anchors solar panels, air-conditioners and antennas.", renter: "Secure outdoor furniture and items yourself before storms.", landlord: false, suggested: false, guidance: IBHS },
];

export const HAZARD_LABEL: Record<Hazard, string> = {
  flood: "Flood",
  fire: "Bushfire / wildfire",
  heat: "Extreme heat",
  wind: "Severe wind",
  cyclone: "Cyclone / hurricane",
};

/** Cyclone/hurricane shares the wind upgrade group. */
export function upgradeGroup(h: Hazard): Hazard {
  return h === "cyclone" ? "wind" : h;
}

export function defaultUpgrades(): Upgrades {
  const u = {} as Upgrades;
  for (const d of UPGRADES) u[d.id] = { on: false, value: d.param.default };
  return u;
}

/**
 * Rough installed-cost ranges in US dollars at US prices, for a typical ~150 m² detached
 * house at the upgrade's default setting. Order-of-magnitude only, compiled from public
 * US cost guidance (FEMA P-312 homeowner retrofitting guide, IBHS, US DOE / Energy Star
 * consumer guides). Scaled by the setting and by the country's World Bank price level.
 */
export const COST: Record<UpgradeId, [number, number]> = {
  raise_floor: [30000, 90000], flood_finishes: [8000, 25000], elevate_services: [3000, 12000], permeable: [4000, 15000], drainage: [2000, 10000], rain_storage: [2000, 6000],
  ext_shading: [3000, 12000], insulation: [2000, 6000], cross_vent: [500, 4000], cool_roof: [3000, 15000], glazing_up: [4000, 20000],
  ember_seal: [1000, 5000], fuel_mgmt: [200, 2000], gutters: [150, 500], cladding: [10000, 40000],
  roof_conn: [3000, 15000], openings: [5000, 25000], big_doors: [1500, 5000], roof_fixings: [1500, 6000], fixtures: [300, 1500],
};
export const COST_SOURCE = "Rough US cost guides (FEMA P-312, IBHS, US DOE) × World Bank price level. Get local quotes.";

export function costRange(id: UpgradeId, value: number, priceLevel: number | null, apartment = false): [number, number] {
  const d = UPGRADES.find((u) => u.id === id)!;
  const f = d.param.default > 0 ? Math.min(3, Math.max(0.1, value / d.param.default)) : 1;
  const k = f * (priceLevel ?? 1) * (apartment ? 0.6 : 1);
  const round = (v: number) => (v >= 1000 ? Math.round(v / 100) * 100 : Math.round(v / 10) * 10);
  const [lo, hi] = COST[id];
  return [round(lo * k), round(hi * k)];
}

export function fmtUsd(v: number): string {
  return `US$${v >= 10000 ? `${Math.round(v / 1000)}k` : v.toLocaleString("en-US")}`;
}
