/**
 * Haven teaching model — deterministic, transparent, illustrative only.
 * Every factor here is a teaching assumption, not a calibrated engineering value.
 * Outputs: concrete measures where possible (water above floor) plus an
 * "Illustrative stress index" from 0 to 10 used only to compare the same
 * event before and after upgrades. It is not a probability, damage % or safety score.
 */
import type { FloodKind, Hazard, House, SiteEvidence, SiteInputs, Surroundings, UpgradeId, Upgrades } from "./types";

export const clamp = (v: number, a = 0, b = 10) => Math.min(b, Math.max(a, v));
const smooth = (x: number) => {
  const c = clamp(x, 0, 1);
  return c * c * (3 - 2 * c);
};

/** Event envelope over the timeline t∈[0,1]: build to peak at 0.5, then partial recession. */
export function envelope(t: number): number {
  return t <= 0.5 ? smooth(t / 0.5) : 1 - 0.55 * smooth((t - 0.5) / 0.5);
}

export type Origin = "evidence" | "user" | "assumed" | "unavailable";
export interface Val<T> {
  value: T | null;
  origin: Origin;
  beyond?: boolean;
}

export interface EffectiveSite {
  elevationM: Val<number>;
  slopeDeg: Val<number>;
  waterDistM: Val<number>;
  coastDistM: Val<number>;
  vegDistM: Val<number>;
  soilTexture: Val<"sandy" | "loamy" | "clay" | "unknown">;
  hardSurfacePct: Val<number>;
  shadePct: Val<number>;
  inputs: SiteInputs;
  /** Input fields filled automatically from public data (user left them unknown). */
  auto: ("surroundings" | "windExposure")[];
}

/** Derive site inputs from public evidence. Pure; returns only what data supports. */
export function autoSite(ev: SiteEvidence | null): Partial<Pick<SiteInputs, "surroundings" | "windExposure">> {
  if (!ev) return {};
  const out: Partial<Pick<SiteInputs, "surroundings" | "windExposure">> = {};
  const coast = ev.coast?.status === "estimate" ? ev.coast.value?.distanceM : undefined;
  const veg = ev.vegetation?.status === "estimate" ? ev.vegetation.value?.distanceM : undefined;
  const b = ev.buildings?.status === "estimate" ? ev.buildings.value : undefined;
  const LU: Record<string, Surroundings> = { residential: "suburban", commercial: "urban", retail: "urban", industrial: "urban", farmland: "rural", meadow: "rural", farmyard: "rural", orchard: "rural", forest: "bushland" };
  if (coast != null && coast < 1000) out.surroundings = "coastal";
  else if (b && b.count300m >= 250) out.surroundings = "urban";
  else if (b && b.count300m >= 40) out.surroundings = veg != null && veg < 100 ? "bushland" : "suburban";
  else if (b?.landuse && LU[b.landuse]) out.surroundings = LU[b.landuse]!;
  else if (b && b.count300m >= 5) out.surroundings = veg != null && veg < 200 ? "bushland" : "rural";
  // Fewer than 5 mapped buildings and no land use: mapping too sparse to judge — leave unknown.
  const relief = ev.relief?.status === "estimate" ? ev.relief.value : undefined;
  if (relief != null && relief >= 15) out.windExposure = "hilltop";
  else if (out.surroundings === "urban" || out.surroundings === "suburban") out.windExposure = "sheltered";
  else if (out.surroundings) out.windExposure = "open";
  return out;
}

/** Suggested house fields from the mapped building at the point (if any). */
export function autoHouse(ev: SiteEvidence | null): Partial<Pick<House, "type" | "roof" | "walls">> {
  const n = ev?.buildings?.status === "estimate" ? ev.buildings.value?.nearest : null;
  if (!n) return {};
  const out: Partial<Pick<House, "type" | "roof" | "walls">> = {};
  const t = n.building;
  if (["house", "detached", "bungalow", "farm"].includes(t)) out.type = "detached";
  else if (["terrace", "semidetached_house", "townhouse"].includes(t)) out.type = "attached";
  else if (["apartments", "residential"].includes(t) && (n.levels ?? 0) >= 3) out.type = "apartment";
  else if (t === "apartments") out.type = "apartment";
  const r = n.roofShape;
  if (r === "gabled") out.roof = "gable";
  else if (r === "hipped" || r === "half-hipped") out.roof = "hip";
  else if (r === "flat") out.roof = "flat";
  else if (r === "skillion") out.roof = "skillion";
  const m = n.material;
  if (m && ["brick", "stone", "concrete", "masonry", "cement_block"].includes(m)) out.walls = "masonry";
  else if (m && ["wood", "timber_framing"].includes(m)) out.walls = "timber";
  else if (m && ["metal", "plastic"].includes(m)) out.walls = "lightweight";
  return out;
}

export interface Presets {
  values: [number, number, number];
  local: boolean;
  basis?: string;
}
/** Mild/Strong/Extreme from local records where available; otherwise generic teaching values. */
export function presetsFor(h: Hazard, ev: SiteEvidence | null): Presets {
  const cfg = INTENSITY[h];
  const c = ev?.climate?.status === "estimate" ? ev.climate.value : undefined;
  const fit = (v: number) => Math.min(cfg.max, Math.max(cfg.min, Math.round(v / cfg.step) * cfg.step));
  if (c && h === "heat") return { values: [fit(c.tmaxP95), fit(c.tmaxP99), fit(c.tmaxRecord)], local: true, basis: `Local ${c.period}: hot day (95th pct), very hot day (99th pct), record` };
  if (c && h === "wind") return { values: [fit(c.gustP95), fit(c.gustP99), fit(c.gustRecord)], local: true, basis: `Local ${c.period}: windy day (95th pct), storm day (99th pct), record gust` };
  return { values: cfg.presets, local: false };
}

const HARD_DEFAULT = { urban: 70, suburban: 50, rural: 15, coastal: 40, bushland: 25, unknown: 45 } as const;

function pickNum<T>(user: number | null, ev: { status: string; value?: T; searchRadiusM?: number } | undefined, get: (v: T) => number): Val<number> {
  if (user != null && Number.isFinite(user)) return { value: user, origin: "user" };
  if (ev?.status === "estimate" && ev.value != null) return { value: get(ev.value), origin: "evidence" };
  if (ev?.status === "none-found" && ev.searchRadiusM) return { value: ev.searchRadiusM, origin: "evidence", beyond: true };
  return { value: null, origin: "unavailable" };
}

/** Merge public evidence with user overrides. Evidence objects are never mutated. */
export function effectiveSite(raw: SiteInputs, ev: SiteEvidence | null): EffectiveSite {
  const a = autoSite(ev);
  const auto: EffectiveSite["auto"] = [];
  const s: SiteInputs = { ...raw };
  if (s.surroundings === "unknown" && a.surroundings) { s.surroundings = a.surroundings; auto.push("surroundings"); }
  if (s.windExposure === "unknown" && a.windExposure) { s.windExposure = a.windExposure; auto.push("windExposure"); }
  const soil: Val<"sandy" | "loamy" | "clay" | "unknown"> =
    s.soilTexture !== "unknown"
      ? { value: s.soilTexture, origin: "user" }
      : ev?.soil?.status === "estimate" && ev.soil.value
        ? { value: ev.soil.value.texture, origin: "evidence" }
        : { value: "unknown", origin: "unavailable" };
  return {
    elevationM: pickNum(s.elevationM, ev?.elevation, (v) => v),
    slopeDeg: pickNum(s.slopeDeg, ev?.slope, (v) => v),
    waterDistM: pickNum(s.waterDistM, ev?.waterway, (v) => v.distanceM),
    coastDistM: pickNum(s.coastDistM, ev?.coast, (v) => v.distanceM),
    vegDistM: pickNum(s.vegDistM, ev?.vegetation, (v) => v.distanceM),
    soilTexture: soil,
    hardSurfacePct: s.hardSurfacePct != null ? { value: s.hardSurfacePct, origin: "user" } : { value: HARD_DEFAULT[s.surroundings], origin: "assumed" },
    shadePct: s.shadePct != null ? { value: s.shadePct, origin: "user" } : { value: 20, origin: "assumed" },
    inputs: s,
    auto,
  };
}

export interface Metric {
  label: string;
  value: string;
  emphasis?: boolean;
}
export interface Result {
  stress: number;
  metrics: Metric[];
  notes: string[];
}

type U = (id: UpgradeId) => number | null;
const upgradeGetter = (up: Upgrades, enabled: boolean): U => (id) => (enabled && up[id]?.on ? up[id].value : null);

// ---------- Flood ----------
export function waterAboveFloor(depthM: number, floorHeightM: number, addedM: number): number {
  return Math.max(0, depthM - floorHeightM - addedM);
}

export function surfaceWaterLoad(site: EffectiveSite, u: U): number {
  const s = site.inputs;
  const hard = (site.hardSurfacePct.value ?? 45) / 100;
  const perm = (u("permeable") ?? 0) / 100;
  const hardTerm = 4 * hard * (1 - 0.8 * perm);
  const drainBase = { pools: 3, some: 2, free: 0.5, unknown: 2 }[s.drainage];
  const drainTerm = drainBase * (1 - 0.6 * ((u("drainage") ?? 0) / 100));
  const groundTerm = { lower: 2, level: 1, raised: 0.3, unknown: 1.2 }[s.groundVsStreet];
  const soilTerm = { clay: 1.5, loamy: 0.8, sandy: 0.3, unknown: 1 }[site.soilTexture.value ?? "unknown"] * (s.soilCondition === "saturated" ? 1.5 : 1);
  const storage = Math.min(1, (u("rain_storage") ?? 0) / 10000) * 0.8;
  return clamp(hardTerm + drainTerm + groundTerm + soilTerm - storage);
}

export function floodResult(depthM: number, kind: FloodKind, house: House, site: EffectiveSite, up: Upgrades, withUp: boolean): Result {
  const u = upgradeGetter(up, withUp);
  const added = u("raise_floor") ?? 0;
  const floor = house.floorHeightM + added;
  const waf = waterAboveFloor(depthM, house.floorHeightM, added);
  const svc = Math.max(house.servicesHeightM, u("elevate_services") ?? 0);
  const servicesWet = depthM > svc;
  const fin = (u("flood_finishes") ?? 0) / 100;
  let stress = waf > 0 ? 3 + waf * 4 : depthM > 0 ? Math.min(2.5, (depthM / Math.max(floor, 0.1)) * 2.5) : 0;
  if (servicesWet) stress += 1.5;
  stress *= 1 - 0.3 * fin * (waf > 0 ? 1 : 0.5);
  const metrics: Metric[] = [
    { label: "Water depth at ground", value: `${depthM.toFixed(2)} m` },
    { label: "Habitable floor above ground", value: `${floor.toFixed(2)} m${added > 0 ? ` (+${added.toFixed(2)})` : ""}` },
    { label: "Water above floor", value: `${waf.toFixed(2)} m`, emphasis: true },
    { label: "Essential services", value: servicesWet ? `Below water (at ${svc.toFixed(1)} m)` : `Above water (at ${svc.toFixed(1)} m)` },
  ];
  const notes: string[] = [];
  if (kind === "surface") {
    metrics.push({ label: "Surface-water load (illustrative, 0–10)", value: surfaceWaterLoad(site, u).toFixed(1) });
    notes.push("Drainage, paving and storage change the surface-water load only. They do not change the depth you selected.");
  } else {
    notes.push(`Permeable paving, drainage and storage have no modelled effect on ${kind === "river" ? "river" : "coastal"} inundation.`);
  }
  return { stress: clamp(stress), metrics, notes };
}

// ---------- Fire ----------
export function fireResult(exposure: number, house: House, site: EffectiveSite, up: Upgrades, withUp: boolean): Result {
  const u = upgradeGetter(up, withUp);
  const veg = site.vegDistM.value;
  const vegF = veg == null ? 1.1 : veg < 100 ? 1.3 : veg < 500 ? 1.1 : 0.9; // unknown is NOT treated as low
  const slope = site.slopeDeg.value;
  const slopeF = slope == null ? 1.05 : slope > 10 ? 1.2 : slope > 5 ? 1.1 : 1;
  const surF = { bushland: 1.25, rural: 1.1, coastal: 1, suburban: 0.95, urban: 0.85, unknown: 1 }[site.inputs.surroundings];
  const wallF = { timber: 1.15, lightweight: 1.1, mixed: 1, masonry: 0.9 }[house.walls];
  const claddingWeight = house.walls === "masonry" ? 0.06 : 0.2; // avoid double-counting existing masonry
  const r = 0.3 * ((u("ember_seal") ?? 0) / 100) + 0.25 * ((u("fuel_mgmt") ?? 0) / 100) + 0.15 * ((u("gutters") ?? 0) / 100) + claddingWeight * ((u("cladding") ?? 0) / 100);
  const stress = clamp(exposure * vegF * slopeF * surF * wallF * (1 - r));
  return {
    stress,
    metrics: [
      { label: "Selected exposure", value: `${exposure.toFixed(1)} / 10` },
      { label: "Vegetation factor", value: veg == null ? "Unknown (cautious)" : `${vegF.toFixed(2)}×` },
      { label: "Terrain factor", value: `${slopeF.toFixed(2)}×` },
      { label: "Upgrade reduction (model)", value: `${Math.round(r * 100)}%`, emphasis: true },
    ],
    notes: ["This does not predict ignition or survival. Follow local fire authority advice."],
  };
}

// ---------- Heat ----------
export function heatResult(tempC: number, house: House, site: EffectiveSite, up: Upgrades, withUp: boolean): Result {
  const u = upgradeGetter(up, withUp);
  const excess = Math.max(0, tempC - 24) / 2;
  const insLevel = Math.max(house.insulation, u("insulation") ?? 0) as 0 | 1 | 2 | 3;
  const insF = ([1.3, 1.1, 0.9, 0.75] as const)[insLevel];
  const glazeBase = { single: 1.15, double: 1, performance: 0.9 }[house.glazing];
  const gcov = (u("glazing_up") ?? 0) / 100;
  const glazeF = glazeBase - gcov * Math.max(0, glazeBase - 0.9);
  const orientF = { W: 1.15, E: 1.05, N: 1, S: 1 }[house.orientation];
  const roofBase = { dark: 1.15, medium: 1, light: 0.9 }[house.roofColour];
  const roofF = roofBase - ((u("cool_roof") ?? 0) / 100) * Math.max(0, roofBase - 0.88);
  const shade = (site.shadePct.value ?? 20) / 100;
  const hard = (site.hardSurfacePct.value ?? 45) / 100;
  const siteF = (1 - 0.25 * shade) * (1 + 0.15 * hard);
  const upF = (1 - 0.2 * ((u("ext_shading") ?? 0) / 100)) * (1 - 0.12 * ((u("cross_vent") ?? 0) / 100));
  const factor = insF * glazeF * orientF * roofF * siteF * upF;
  return {
    stress: clamp(excess * factor * 0.85),
    metrics: [
      { label: "Outdoor temperature", value: `${tempC.toFixed(0)} °C` },
      { label: "Envelope factor (model)", value: `${(insF * glazeF * roofF).toFixed(2)}×` },
      { label: "Site factor (shade, paving)", value: `${siteF.toFixed(2)}×` },
      { label: "Combined heat-gain factor", value: `${factor.toFixed(2)}×`, emphasis: true },
    ],
    notes: ["Not an indoor temperature or energy forecast."],
  };
}

// ---------- Wind ----------
export function windResult(gustKmh: number, house: House, site: EffectiveSite, up: Upgrades, withUp: boolean): Result {
  const u = upgradeGetter(up, withUp);
  const load = (gustKmh / 150) ** 2 * 6;
  const terrF = { sheltered: 0.8, open: 1, hilltop: 1.3, unknown: 1.05 }[site.inputs.windExposure];
  const roofF = { hip: 0.85, gable: 1, flat: 1.1, skillion: 1.1 }[house.roof];
  const r = 0.3 * ((u("roof_conn") ?? 0) / 100) + 0.2 * ((u("openings") ?? 0) / 100) + 0.12 * ((u("big_doors") ?? 0) / 100) + 0.2 * ((u("roof_fixings") ?? 0) / 100) + 0.08 * ((u("fixtures") ?? 0) / 100);
  return {
    stress: clamp(load * terrF * roofF * (1 - r)),
    metrics: [
      { label: "Gust speed", value: `${gustKmh.toFixed(0)} km/h` },
      { label: "Terrain factor", value: `${terrF.toFixed(2)}×` },
      { label: "Roof form factor", value: `${roofF.toFixed(2)}×` },
      { label: "Upgrade reduction (model)", value: `${Math.round(r * 100)}%`, emphasis: true },
    ],
    notes: ["Not a structural rating or failure prediction."],
  };
}

export function computeResult(h: Hazard, intensity: number, kind: FloodKind, house: House, site: EffectiveSite, up: Upgrades, withUp: boolean): Result {
  if (h === "flood") return floodResult(intensity, kind, house, site, up, withUp);
  if (h === "fire") return fireResult(intensity, house, site, up, withUp);
  if (h === "heat") return heatResult(intensity, house, site, up, withUp);
  // Wind and cyclone/hurricane share the gust model; cyclone uses a higher range.
  return windResult(intensity, house, site, up, withUp);
}

/** Intensity at timeline position. Heat: ramps from a 24 °C baseline. */
export function intensityAt(h: Hazard, peak: number, t: number): number {
  const e = envelope(t);
  if (h === "heat") return 24 + (peak - 24) * e;
  return peak * e;
}

export const INTENSITY: Record<Hazard, { label: string; unit: string; min: number; max: number; step: number; presets: [number, number, number] }> = {
  flood: { label: "Water depth above local ground", unit: "m", min: 0, max: 3, step: 0.05, presets: [0.3, 0.9, 1.8] },
  fire: { label: "Exposure intensity", unit: "/10", min: 1, max: 10, step: 0.5, presets: [3, 6, 9] },
  heat: { label: "Outdoor temperature", unit: "°C", min: 28, max: 50, step: 1, presets: [35, 41, 46] },
  wind: { label: "Peak gust", unit: "km/h", min: 40, max: 280, step: 5, presets: [90, 150, 220] },
  cyclone: { label: "Peak gust", unit: "km/h", min: 60, max: 320, step: 5, presets: [150, 220, 280] },
};

export function stressBand(s: number): string {
  if (s < 2) return "Low modelled stress";
  if (s < 4.5) return "Moderate modelled stress";
  if (s < 7) return "High modelled stress";
  return "Very high modelled stress";
}

/** Screening notes — mechanisms worth investigating, never predictions. */
export function screeningNotes(site: EffectiveSite, ev: SiteEvidence | null = null): { hazard: Hazard; text: string }[] {
  const n: { hazard: Hazard; text: string }[] = [];
  const cl = ev?.climate?.status === "estimate" ? ev.climate.value : undefined;
  const fu = ev?.future?.status === "estimate" ? ev.future.value : undefined;
  if (cl && cl.hotDays35PerYr >= 1) n.push({ hazard: "heat", text: `About ${cl.hotDays35PerYr} days a year reached 35 °C here (${cl.period}).` });
  if (fu && fu.hotDays35Future - fu.hotDays35Base >= 2) n.push({ hazard: "heat", text: `One climate model shows ${fu.hotDays35Base} → ${fu.hotDays35Future} days a year ≥ 35 °C by ${fu.futurePeriod}.` });
  if (cl && cl.gustRecord >= 100) n.push({ hazard: "wind", text: `Gusts reached ${cl.gustRecord} km/h here in ${cl.period}.` });
  const s = site.inputs;
  if (s.groundVsStreet === "lower" || s.drainage === "pools" || s.drainage === "some") n.push({ hazard: "flood", text: "Low ground or poor drainage can let surface water collect." });
  const w = site.waterDistM;
  if (w.value != null && !w.beyond && w.value < 1000) n.push({ hazard: "flood", text: `A mapped waterway is about ${fmtDist(w.value)} away — check local flood mapping.` });
  const c = site.coastDistM;
  if ((c.value != null && !c.beyond && c.value < 3000) || s.surroundings === "coastal") n.push({ hazard: "flood", text: "Coastal setting — check storm-tide and coastal inundation mapping." });
  const v = site.vegDistM;
  if ((v.value != null && !v.beyond && v.value < 500) || s.surroundings === "bushland") n.push({ hazard: "fire", text: "Nearby vegetation can bring embers and radiant heat closer." });
  if ((site.slopeDeg.value ?? 0) > 5) n.push({ hazard: "fire", text: "Sloping terrain can speed fire travelling uphill." });
  if ((site.hardSurfacePct.value ?? 0) >= 50 || (site.shadePct.value ?? 100) < 20) n.push({ hazard: "heat", text: "Extensive paving and little shade can worsen heat around the home." });
  if (s.windExposure === "open" || s.windExposure === "hilltop") n.push({ hazard: "wind", text: "Open terrain or hilltops can increase wind exposure." });
  if ((c.value != null && !c.beyond && c.value < 20000) || s.surroundings === "coastal") n.push({ hazard: "cyclone", text: "Coastal regions in some parts of the world experience cyclones, hurricanes or typhoons — check whether this area is affected." });
  if (n.length === 0) n.push({ hazard: "heat", text: "No screening triggers from current data. Missing data is not evidence of low exposure." });
  return n;
}

export function fmtDist(m: number): string {
  return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
}
