import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import type { Calibration, FloodKind, Hazard, House, Photo, Place, SiteEvidence, SiteInputs, Upgrades } from "./types";
import { defaultUpgrades } from "./upgrades";
import { INTENSITY } from "./model";

export const DEFAULT_SITE: SiteInputs = {
  surroundings: "unknown",
  groundVsStreet: "unknown",
  drainage: "unknown",
  soilTexture: "unknown",
  soilCondition: "normal",
  windExposure: "unknown",
  hardSurfacePct: null,
  shadePct: null,
  elevationM: null,
  slopeDeg: null,
  waterDistM: null,
  coastDistM: null,
  vegDistM: null,
};

export const DEFAULT_HOUSE: House = {
  mode: "build",
  type: "detached",
  walls: "masonry",
  floorHeightM: 0.3,
  roof: "gable",
  insulation: 1,
  glazing: "single",
  orientation: "W",
  roofColour: "medium",
  servicesHeightM: 0.3,
};

export interface AppState {
  step: number;
  place: Place | null;
  evidence: SiteEvidence | null;
  evidenceStatus: "idle" | "loading" | "ready" | "error";
  site: SiteInputs;
  house: House;
  upgrades: Upgrades;
  hazard: Hazard;
  floodKind: FloodKind;
  intensity: Record<Hazard, number>;
  photo: Photo | null;
  calib: Calibration;
  explored: Hazard[];
  compared: Hazard[];
  /** House fields filled from map data. */
  houseAuto: string[];
  /** House fields the user has changed (never auto-overwritten). */
  houseEdited: string[];
}

const initial = (): AppState => ({
  step: 0,
  place: null,
  evidence: null,
  evidenceStatus: "idle",
  site: DEFAULT_SITE,
  house: DEFAULT_HOUSE,
  upgrades: defaultUpgrades(),
  hazard: "flood",
  floodKind: "river",
  intensity: { flood: INTENSITY.flood.presets[1], fire: INTENSITY.fire.presets[1], heat: INTENSITY.heat.presets[1], wind: INTENSITY.wind.presets[1], cyclone: INTENSITY.cyclone.presets[1] },
  photo: null,
  calib: { groundPct: 86, eavesPct: 42, groundToEavesM: 3 },
  explored: [],
  compared: [],
  houseAuto: [],
  houseEdited: [],
});

interface Ctx {
  s: AppState;
  set: (fn: (s: AppState) => Partial<AppState>) => void;
  /** New location: clears evidence, photo and location-specific overrides; keeps house & upgrades. */
  selectPlace: (p: Place) => void;
  /** Restore a saved or shared snapshot. */
  load: (snap: Snapshot) => void;
}

export interface Snapshot {
  v: 1;
  place: Place;
  evidence: SiteEvidence | null;
  site: SiteInputs;
  house: House;
  upgrades: Upgrades;
  photo: Photo | null;
  calib: Calibration;
  intensity: Record<Hazard, number>;
  floodKind: FloodKind;
}

export function toSnapshot(s: AppState): Snapshot | null {
  if (!s.place) return null;
  return { v: 1, place: s.place, evidence: s.evidence, site: s.site, house: s.house, upgrades: s.upgrades, photo: s.photo, calib: s.calib, intensity: s.intensity, floodKind: s.floodKind };
}

const C = createContext<Ctx | null>(null);

export function HavenProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<AppState>(initial);
  const set = useCallback((fn: (s: AppState) => Partial<AppState>) => setS((prev) => ({ ...prev, ...fn(prev) })), []);
  const selectPlace = useCallback(
    (p: Place) =>
      setS((prev) => ({
        ...prev,
        place: p,
        evidence: null,
        evidenceStatus: "loading",
        photo: null,
        site: { ...DEFAULT_SITE },
        houseAuto: [],
        step: 1,
      })),
    [],
  );
  const load = useCallback(
    (n: Snapshot) =>
      setS((prev) => ({
        ...prev,
        place: n.place,
        evidence: n.evidence,
        evidenceStatus: n.evidence ? "ready" : "loading",
        site: { ...DEFAULT_SITE, ...n.site },
        house: { ...DEFAULT_HOUSE, ...n.house },
        upgrades: { ...defaultUpgrades(), ...n.upgrades },
        photo: n.photo,
        calib: n.calib ?? prev.calib,
        intensity: { ...prev.intensity, ...n.intensity },
        floodKind: n.floodKind ?? "river",
        houseAuto: [],
        houseEdited: Object.keys(n.house ?? {}),
        step: 1,
      })),
    [],
  );
  return <C.Provider value={{ s, set, selectPlace, load }}>{children}</C.Provider>;
}

export function useHaven() {
  const c = useContext(C);
  if (!c) throw new Error("useHaven outside provider");
  return c;
}
