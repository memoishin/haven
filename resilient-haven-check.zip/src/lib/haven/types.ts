export type Precision = "address" | "street" | "locality" | "manual";

export interface Place {
  lat: number;
  lon: number;
  label: string;
  locality?: string;
  region?: string;
  country?: string;
  countryCode?: string;
  precision: Precision;
  source: string;
  demo?: boolean;
}

/** estimate = public remote estimate; none-found = searched, nothing mapped in radius; unavailable = provider failed / no coverage */
export type EvidenceStatus = "estimate" | "none-found" | "unavailable";

export interface Evidence<T> {
  status: EvidenceStatus;
  value?: T;
  unit?: string;
  source: string;
  sourceUrl?: string;
  licence?: string;
  retrieved: string;
  resolution?: string;
  limitations: string;
  note?: string;
  lat: number;
  lon: number;
  searchRadiusM?: number;
}

export interface SoilValue {
  clayPct: number;
  sandPct: number;
  siltPct: number;
  texture: "sandy" | "loamy" | "clay";
}

export interface ClimateValue {
  period: string;
  tmaxRecord: number;
  tmaxP95: number;
  tmaxP99: number;
  hotDays35PerYr: number;
  gustRecord: number;
  gustP95: number;
  gustP99: number;
}
export interface FutureValue {
  model: string;
  basePeriod: string;
  futurePeriod: string;
  hotDays35Base: number;
  hotDays35Future: number;
  tmaxRecordFuture: number;
}
export interface RiverValue {
  period: string;
  maxM3s: number;
  p99M3s: number;
  medianM3s: number;
  maxDate: string;
}
export interface BuildingValue {
  count300m: number;
  landuse: string | null;
  nearest: { distanceM: number; building: string; levels?: number; roofShape?: string; material?: string } | null;
}

export interface SiteEvidence {
  elevation: Evidence<number>;
  slope: Evidence<number>;
  relief?: Evidence<number>;
  soil: Evidence<SoilValue>;
  waterway: Evidence<{ distanceM: number; name?: string; kind: string }>;
  coast: Evidence<{ distanceM: number }>;
  vegetation: Evidence<{ distanceM: number; kind: string }>;
  climate?: Evidence<ClimateValue>;
  future?: Evidence<FutureValue>;
  river?: Evidence<RiverValue>;
  buildings?: Evidence<BuildingValue>;
  priceLevel?: Evidence<number>;
}

export type Surroundings = "urban" | "suburban" | "rural" | "coastal" | "bushland" | "unknown";

export interface SiteInputs {
  surroundings: Surroundings;
  groundVsStreet: "lower" | "level" | "raised" | "unknown";
  drainage: "pools" | "some" | "free" | "unknown";
  soilTexture: "sandy" | "loamy" | "clay" | "unknown";
  soilCondition: "normal" | "saturated";
  windExposure: "sheltered" | "open" | "hilltop" | "unknown";
  hardSurfacePct: number | null;
  shadePct: number | null;
  elevationM: number | null;
  slopeDeg: number | null;
  waterDistM: number | null;
  coastDistM: number | null;
  vegDistM: number | null;
}

export interface House {
  mode: "build" | "rent";
  type: "detached" | "attached" | "apartment" | "raised";
  walls: "masonry" | "timber" | "lightweight" | "mixed";
  floorHeightM: number;
  roof: "gable" | "hip" | "flat" | "skillion";
  insulation: 0 | 1 | 2 | 3;
  glazing: "single" | "double" | "performance";
  orientation: "N" | "E" | "S" | "W";
  roofColour: "dark" | "medium" | "light";
  servicesHeightM: number;
}

export type Hazard = "flood" | "fire" | "heat" | "wind" | "cyclone";
export type FloodKind = "river" | "surface" | "coastal";

export interface UpgradeState {
  on: boolean;
  value: number;
}
export type UpgradeId =
  | "raise_floor" | "flood_finishes" | "elevate_services" | "permeable" | "drainage" | "rain_storage"
  | "ext_shading" | "insulation" | "cross_vent" | "cool_roof" | "glazing_up"
  | "ember_seal" | "fuel_mgmt" | "gutters" | "cladding"
  | "roof_conn" | "openings" | "big_doors" | "roof_fixings" | "fixtures";
export type Upgrades = Record<UpgradeId, UpgradeState>;

export interface Photo {
  url: string;
  title: string;
  pageUrl: string;
  artist?: string | undefined;
  licence?: string | undefined;
  licenceUrl?: string | undefined;
  date?: string | undefined;
  kind: "nearby" | "example";
  distanceM?: number | undefined;
  confirmedByUser?: boolean;
}

export interface Calibration {
  groundPct: number;
  eavesPct: number;
  groundToEavesM: number;
}
