import { describe, expect, it } from "vitest";
import { computeResult, effectiveSite, envelope, waterAboveFloor, surfaceWaterLoad } from "./model";
import { DEFAULT_HOUSE, DEFAULT_SITE } from "./state";
import { defaultUpgrades, UPGRADES } from "./upgrades";
import type { SiteEvidence, UpgradeId } from "./types";

const site = effectiveSite(DEFAULT_SITE, null);

describe("flood depth", () => {
  it("water above floor formula", () => {
    expect(waterAboveFloor(1.2, 0.3, 0)).toBeCloseTo(0.9);
    expect(waterAboveFloor(1.2, 0.3, 0.5)).toBeCloseTo(0.4);
    expect(waterAboveFloor(0.2, 0.3, 0)).toBe(0);
  });
  it("paving/drainage/storage never change river results", () => {
    const up = defaultUpgrades();
    for (const id of ["permeable", "drainage", "rain_storage"] as const) up[id].on = true;
    const a = computeResult("flood", 1, "river", DEFAULT_HOUSE, site, up, false);
    const b = computeResult("flood", 1, "river", DEFAULT_HOUSE, site, up, true);
    expect(b.stress).toBe(a.stress);
    expect(b.metrics[2]?.value).toBe(a.metrics[2]?.value);
  });
  it("surface upgrades lower surface load only", () => {
    const up = defaultUpgrades();
    up.drainage.on = true;
    const g0 = (_id: UpgradeId) => null;
    const g1 = (id: UpgradeId) => (up[id].on ? up[id].value : null);
    expect(surfaceWaterLoad(site, g1)).toBeLessThan(surfaceWaterLoad(site, g0));
  });
});

describe("upgrades", () => {
  it("has 20 upgrades", () => expect(UPGRADES).toHaveLength(20));
  it("existing high insulation is not double counted", () => {
    const up = defaultUpgrades();
    up.insulation.on = true;
    const house = { ...DEFAULT_HOUSE, insulation: 3 as const };
    expect(computeResult("heat", 42, "river", house, site, up, true).stress).toBe(computeResult("heat", 42, "river", house, site, up, false).stress);
  });
});

describe("site", () => {
  it("user overrides win but evidence is kept", () => {
    const ev = { elevation: { status: "estimate", value: 12, source: "x", retrieved: "", limitations: "", lat: 0, lon: 0 } } as unknown as SiteEvidence;
    const e = effectiveSite({ ...DEFAULT_SITE, elevationM: 5 }, ev);
    expect(e.elevationM).toEqual({ value: 5, origin: "user" });
    expect(ev.elevation.value).toBe(12);
  });
  it("missing vegetation data is not treated as low exposure", () => {
    const far = effectiveSite({ ...DEFAULT_SITE, vegDistM: 1500 }, null);
    const up = defaultUpgrades();
    expect(computeResult("fire", 6, "river", DEFAULT_HOUSE, site, up, false).stress).toBeGreaterThan(computeResult("fire", 6, "river", DEFAULT_HOUSE, far, up, false).stress);
  });
  it("envelope peaks at 0.5", () => {
    expect(envelope(0.5)).toBe(1);
    expect(envelope(0)).toBe(0);
  });
});

import { autoSite, presetsFor } from "./model";
import { costRange } from "./upgrades";
describe("auto + presets + cost", () => {
  const base: any = { elevation: { status: "unavailable" }, slope: { status: "unavailable" }, soil: { status: "unavailable" }, waterway: { status: "unavailable" }, coast: { status: "unavailable" }, vegetation: { status: "unavailable" } };
  it("leaves surroundings unknown when mapping is sparse", () => {
    expect(autoSite({ ...base, buildings: { status: "estimate", value: { count300m: 0, landuse: null, nearest: null } } }).surroundings).toBeUndefined();
  });
  it("detects urban from dense buildings", () => {
    expect(autoSite({ ...base, buildings: { status: "estimate", value: { count300m: 400, landuse: null, nearest: null } } }).surroundings).toBe("urban");
  });
  it("uses local heat records for presets", () => {
    const p = presetsFor("heat", { ...base, climate: { status: "estimate", value: { period: "x", tmaxRecord: 44, tmaxP95: 33, tmaxP99: 37, hotDays35PerYr: 3, gustRecord: 100, gustP95: 50, gustP99: 70 } } });
    expect(p.local).toBe(true);
    expect(p.values).toEqual([33, 37, 44]);
  });
  it("scales cost by price level", () => {
    const [a] = costRange("gutters", 100, 1);
    const [b] = costRange("gutters", 100, 0.5);
    expect(b).toBeLessThan(a);
  });
});
