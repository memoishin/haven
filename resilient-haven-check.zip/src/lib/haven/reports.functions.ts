import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

function publicClient() {
  return import("@supabase/supabase-js").then(({ createClient }) =>
    createClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!, {
      auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    }),
  );
}

export const createShare = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ snapshot: z.record(z.string(), z.unknown()) }).parse(d))
  .handler(async ({ data }) => {
    const sb = await publicClient();
    const { data: slug, error } = await sb.rpc("create_shared_report", { _snapshot: data.snapshot as never });
    if (error || typeof slug !== "string") {
      console.error("share", error);
      throw new Error("Could not create a share link.");
    }
    return { slug };
  });

export const getShare = createServerFn({ method: "GET" })
  .inputValidator((d) => z.object({ slug: z.string().regex(/^[A-Za-z0-9_-]{6,40}$/) }).parse(d))
  .handler(async ({ data }) => {
    const sb = await publicClient();
    const { data: snap, error } = await sb.rpc("get_shared_report", { _slug: data.slug });
    if (error) {
      console.error("getShare", error);
      throw new Error("Could not load report.");
    }
    return { json: snap ? JSON.stringify(snap) : null };
  });
