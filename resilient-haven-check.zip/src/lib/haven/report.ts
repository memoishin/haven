import { computeResult, effectiveSite, fmtDist, INTENSITY, presetsFor, screeningNotes, stressBand } from "./model";
import type { Snapshot } from "./state";
import type { Hazard } from "./types";
import { COST_SOURCE, costRange, fmtUsd, HAZARD_LABEL, UPGRADES, upgradeGroup } from "./upgrades";

export interface ReportSection {
  title: string;
  lines: string[];
}

const HAZARDS: Hazard[] = ["flood", "fire", "heat", "wind", "cyclone"];

/** Plain-text report sections built only from the snapshot — shared by PDF and share page. */
export function buildReport(n: Snapshot): ReportSection[] {
  const ev = n.evidence;
  const site = effectiveSite(n.site, ev);
  const out: ReportSection[] = [];
  const p = n.place;
  out.push({ title: "Location", lines: [p.label, `${p.lat.toFixed(5)}, ${p.lon.toFixed(5)} · precision: ${p.precision}`, [p.region, p.country].filter(Boolean).join(", ")] });

  const d = (v: { value: number | null; beyond?: boolean }) => (v.value == null ? "Data unavailable" : v.beyond ? `none within ${fmtDist(v.value)}` : fmtDist(v.value));
  const ev_lines = [
    `Ground elevation: ${site.elevationM.value != null ? `${site.elevationM.value} m above sea level` : "Data unavailable"}`,
    `Slope: ${site.slopeDeg.value != null ? `${site.slopeDeg.value}°` : "Data unavailable"}`,
    `Soil: ${site.soilTexture.value ?? "unknown"}`,
    `Nearest waterway: ${d(site.waterDistM)} · coastline: ${d(site.coastDistM)} · woodland/scrub: ${d(site.vegDistM)}`,
    `Surroundings: ${site.inputs.surroundings}${site.auto.includes("surroundings") ? " (auto from map)" : ""}`,
  ];
  const c = ev?.climate?.status === "estimate" ? ev.climate.value : undefined;
  if (c) ev_lines.push(`Heat ${c.period}: record ${c.tmaxRecord} °C, ${c.hotDays35PerYr} days/yr ≥ 35 °C`, `Gusts ${c.period}: record ${c.gustRecord} km/h`);
  const f = ev?.future?.status === "estimate" ? ev.future.value : undefined;
  if (f) ev_lines.push(`Future heat (${f.model}): ${f.hotDays35Base} → ${f.hotDays35Future} days/yr ≥ 35 °C by ${f.futurePeriod}`);
  const r = ev?.river?.status === "estimate" ? ev.river.value : undefined;
  if (r) ev_lines.push(`River flow ${r.period}: peak ${r.maxM3s} m³/s (${r.maxDate}), usual ${r.medianM3s} m³/s`);
  out.push({ title: "Site evidence (public estimates)", lines: ev_lines });
  out.push({ title: "Risk screening (not a prediction)", lines: screeningNotes(site, ev).map((x) => `${HAZARD_LABEL[x.hazard]}: ${x.text}`) });

  const h = n.house;
  out.push({ title: "House (your inputs)", lines: [`${h.mode === "rent" ? "Renting" : "Building / upgrading"} · ${h.type} · ${h.walls} walls · ${h.roof} roof`, `Habitable floor ${h.floorHeightM.toFixed(2)} m above ground · services at ${h.servicesHeightM.toFixed(1)} m`, `Insulation level ${h.insulation} · ${h.glazing} glazing · main windows face ${h.orientation}`] });

  const pl = ev?.priceLevel?.status === "estimate" ? ev.priceLevel.value ?? null : null;
  const on = UPGRADES.filter((u) => n.upgrades[u.id]?.on);
  let lo = 0, hi = 0;
  const upLines = on.map((u) => {
    const [a, b] = costRange(u.id, n.upgrades[u.id].value, pl, h.type === "apartment");
    lo += a; hi += b;
    return `${u.title} (${u.param.label}: ${n.upgrades[u.id].value} ${u.param.unit}) — ${fmtUsd(a)}–${fmtUsd(b)}`;
  });
  if (on.length) upLines.push(`Total rough cost: ${fmtUsd(lo)}–${fmtUsd(hi)}. ${COST_SOURCE}`);
  out.push({ title: "Selected upgrades", lines: upLines.length ? upLines : ["None selected."] });

  const res: string[] = [];
  for (const hz of HAZARDS) {
    const peak = n.intensity[hz] ?? presetsFor(hz, ev).values[1];
    const a = computeResult(hz, peak, n.floodKind, h, site, n.upgrades, false);
    const b = computeResult(hz, peak, n.floodKind, h, site, n.upgrades, true);
    const anyOn = on.some((u) => u.hazard === upgradeGroup(hz));
    const waf = hz === "flood" ? ` · water above floor ${a.metrics[2]?.value} → ${b.metrics[2]?.value}` : "";
    res.push(`${HAZARD_LABEL[hz]} at ${hz === "flood" ? peak.toFixed(2) : peak} ${INTENSITY[hz].unit}: index ${a.stress.toFixed(1)}${anyOn ? ` → ${b.stress.toFixed(1)}` : ""}/10 (${stressBand(anyOn ? b.stress : a.stress)})${waf}`);
  }
  res.push("Illustrative stress index: teaching model only — not a probability, damage percentage or safety rating.");
  out.push({ title: "Illustrative scenario results (same event, before → with upgrades)", lines: res });
  out.push({ title: "Before acting", lines: ["Check local flood, fire and building authority mapping and rules.", "Get advice and quotes from qualified local professionals before building work."] });
  return out;
}

export async function downloadPdf(n: Snapshot) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 180;
  let y = 18;
  const line = (t: string, size = 10, bold = false) => {
    doc.setFont("helvetica", bold ? "bold" : "normal");
    doc.setFontSize(size);
    for (const l of doc.splitTextToSize(t.replace(/[≥]/g, ">=").replace(/→/g, "->").replace(/[³]/g, "3").replace(/°/g, " deg").replace(/[–—]/g, "-"), W) as string[]) {
      if (y > 282) { doc.addPage(); y = 18; }
      doc.text(l, 15, y);
      y += size * 0.45;
    }
  };
  line("Haven - climate hazard report", 18, true);
  y += 2;
  line(`Generated ${new Date().toLocaleString()} · Illustrative scenario`, 9);
  y += 4;
  for (const s of buildReport(n)) {
    line(s.title, 12, true);
    y += 1;
    for (const l of s.lines) line(`• ${l}`, 9.5);
    y += 4;
  }
  doc.save(`haven-report-${(n.place.locality ?? "place").replace(/\W+/g, "-").toLowerCase()}.pdf`);
}
