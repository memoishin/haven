# Roadmap

- [x] Four-stage flow, visual refresh, cyclone hazard
- [x] Auto-fill site/house from public data (buildings, land use) with Auto badges
- [x] Real climate evidence: heat & gust records (ERA5), future heat (CMIP6), river flow (GloFAS)
- [x] Presets from local records
- [x] Upgrade cost ranges adjusted by country price level
- [x] Soil fallback + retry
- [x] Optional sign-in, saved places, share link
- [x] PDF report
- [ ] Shared evidence cache in Cloud (server memory cache used for now)
- [ ] Fire detections (NASA FIRMS — needs free key from user)
