# Haven — COP31 hackathon prototype · team changemakers

Address-first climate resilience explorer for people building, renovating or renting — worldwide.
Priority: Resilient Cities & Buildings (secondary: climate awareness & education).

## Setup
```
bun install
bun run dev      # http://localhost:8080
bunx vitest run  # model tests
```
No API keys are required. All provider calls run in server functions (`src/lib/haven/providers.functions.ts`).

## Structure
- `src/lib/haven/providers.functions.ts` — data providers (bounded timeouts, caching, independent failure)
- `src/lib/haven/model.ts` — deterministic teaching model (all formulas), tested in `model.test.ts`
- `src/lib/haven/upgrades.ts` — the 20 upgrades
- `src/components/haven/*` — UI (steps, simulation view, particles)

## Connected public sources
| Data | Source | Licence / terms |
|---|---|---|
| Geocoding, reverse geocoding | OpenStreetMap Nominatim | ODbL; ≤1 req/s throttle, UA, caching |
| Map tiles | OpenStreetMap | ODbL, attribution shown |
| Waterways, coastline, vegetation | Overpass API (OSM) | ODbL |
| Elevation + coarse slope | Open-Meteo Elevation (Copernicus GLO-90) | CC BY 4.0 |
| Topsoil texture | ISRIC SoilGrids 2.0 | CC BY 4.0 |
| House photographs | Wikimedia Commons | Per-image open licence, credited |

## Remaining integrations
- National/local flood, wildfire and wind hazard maps (add as new providers).
- Climate reanalysis (ERA5) for local heat/wind history.
- Building-footprint linkage for verified exact-building photos.
- For production: self-hosted or commercial geocoder/tiles to stay within OSM usage policies.
